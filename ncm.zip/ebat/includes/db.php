<?php

function get_books($conn) {
    $sql = "SELECT * FROM books";
    $result = $conn->query($sql);
    return $result;
}


function search_books($conn, $search) {
    $sql = "SELECT * FROM books WHERE title LIKE '%$search%' OR author LIKE '%$search%' OR genre LIKE '%$search%'";
    $result = $conn->query($sql);
    return $result;
}
?>
