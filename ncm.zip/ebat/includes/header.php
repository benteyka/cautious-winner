<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!defined('LOAN_DAYS')) {
    define('LOAN_DAYS', 14);
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$userId = 0;
if (!empty($_SESSION['user_id'])) $userId = (int)$_SESSION['user_id'];
else if (!empty($_SESSION['id'])) $userId = (int)$_SESSION['id'];
else if (!empty($_SESSION['user']['id'])) $userId = (int)$_SESSION['user']['id'];

$userRole = '';
if (!empty($_SESSION['user']['role'])) $userRole = (string)$_SESSION['user']['role'];

$roleText = 'Гость';
$roleAvatar = 'Г';

if ($isAuthorized) {
    if (strtolower($userRole) === 'admin') {
        $roleText = 'Админ';
        $roleAvatar = 'AD';
    } else {
        $roleText = 'Читатель';
        $roleAvatar = 'ЧТ';
    }
}

$authHref = $isAuthorized ? url('/pages/logout.php') : url('/pages/login.php');
$authText = $isAuthorized ? 'Выход' : 'Вход';

function hdr_table_exists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}


$overdueCount = 0;

if ($isAuthorized && $userId > 0 && isset($conn) && ($conn instanceof mysqli)) {
    if (hdr_table_exists($conn, 'book_loans')) {
        $sql = "
            SELECT COUNT(*) AS c
            FROM book_loans
            WHERE user_id = ?
              AND returned_at IS NULL
              AND due_at < NOW()
        ";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $overdueCount = (int)$row['c'];
            }
            $stmt->close();
        }
    }
}
?>

<header class="site-header">
    <div class="site-header-inner">
        <a class="brand-block" href="<?php echo url('/pages/index.php'); ?>">
            <img class="brand-logo" src="<?php echo url('/assets/images/logo.png'); ?>" alt="Логотип" />
            <div class="brand-text">
                <div class="brand-title">Библиотека</div>
                <div class="brand-subtitle">Система управления</div>
            </div>
        </a>

        <div class="header-right">
            <?php if ($isAuthorized && $overdueCount > 0) { ?>
                <div class="overdue-pill" title="Просроченные книги">
                    <span class="overdue-dot" aria-hidden="true"></span>
                    <span class="overdue-text"><?php echo $overdueCount; ?> просрочено</span>
                </div>
            <?php } ?>

            <div class="role-pill">
                <div class="role-avatar"><?php echo htmlspecialchars($roleAvatar); ?></div>
                <div><?php echo htmlspecialchars($roleText); ?></div>
            </div>

            <a class="auth-pill" href="<?php echo $authHref; ?>">
                <span class="auth-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M10 7H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M14 16l4-4-4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M18 12H10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </span>
                <span class="auth-text"><?php echo htmlspecialchars($authText); ?></span>
            </a>
        </div>
    </div>
</header>

<style>
.overdue-pill{
    height: 32px;
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:0 12px;
    border-radius:999px;
    background: rgba(239, 68, 68, 0.10);
    border:1px solid rgba(239, 68, 68, 0.18);
    box-shadow:0 10px 24px rgba(239, 68, 68, 0.10);
    font-weight:900;
    font-size:12px;
    color:#b91c1c;
}
.overdue-dot{
    width:8px;height:8px;border-radius:999px;
    background:#ef4444;
}


.brand-block{
    display:flex !important;
    flex-direction:row !important;
    align-items:center !important;
    gap:12px;
}
.brand-logo{
    width:56px;
    height:56px;
    flex:0 0 auto;
    display:block;
    object-fit:contain;
}
.brand-text{
    display:flex;
    flex-direction:column;
}
</style>