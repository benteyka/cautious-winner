<?php
include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userRole = '';
if (!empty($_SESSION['user']['role'])) $userRole = (string)$_SESSION['user']['role'];
$isAdmin = (strtolower($userRole) === 'admin');

if (!$isAdmin) {
    header("Location: " . url('/pages/index.php'));
    exit;
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Нет соединения с БД"));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . url('/pages/manage.php'));
    exit;
}

$title  = isset($_POST['title']) ? trim($_POST['title']) : '';
$author = isset($_POST['author']) ? trim($_POST['author']) : '';
$genre  = isset($_POST['genre']) ? trim($_POST['genre']) : '';
$isbn   = isset($_POST['isbn']) ? trim($_POST['isbn']) : '';

if ($title === '' || $author === '' || $genre === '') {
    header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Заполни название, автора и жанр"));
    exit;
}


$cols = [];
$res = $conn->query("SHOW COLUMNS FROM `books`");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        if (!empty($r['Field'])) $cols[] = $r['Field'];
    }
}

$hasIsbn = in_array('isbn', $cols, true);
$hasStatus = in_array('status', $cols, true);


if ($hasIsbn && $hasStatus) {
    $sql = "INSERT INTO books (`title`,`author`,`genre`,`isbn`,`status`) VALUES (?,?,?,?, 'available')";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Ошибка INSERT"));
        exit;
    }
    $stmt->bind_param("ssss", $title, $author, $genre, $isbn);
} else if ($hasStatus) {
    $sql = "INSERT INTO books (`title`,`author`,`genre`,`status`) VALUES (?,?,?, 'available')";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Ошибка INSERT"));
        exit;
    }
    $stmt->bind_param("sss", $title, $author, $genre);
} else if ($hasIsbn) {
    $sql = "INSERT INTO books (`title`,`author`,`genre`,`isbn`) VALUES (?,?,?,?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Ошибка INSERT"));
        exit;
    }
    $stmt->bind_param("ssss", $title, $author, $genre, $isbn);
} else {
    $sql = "INSERT INTO books (`title`,`author`,`genre`) VALUES (?,?,?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Ошибка INSERT"));
        exit;
    }
    $stmt->bind_param("sss", $title, $author, $genre);
}

$ok = $stmt->execute();
$stmt->close();

if (!$ok) {
    header("Location: " . url('/pages/manage.php') . "?err=" . urlencode("Не удалось добавить книгу"));
    exit;
}

header("Location: " . url('/pages/manage.php') . "?ok=1");
exit;
