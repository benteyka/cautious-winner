<?php
include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$userRole = '';
if (!empty($_SESSION['user']['role'])) $userRole = (string)$_SESSION['user']['role'];
$isAdmin = (strtolower($userRole) === 'admin');

$activeTab = 'catalog';

function ensure_books_isbn_column(mysqli $conn): void {
    $res = $conn->query("SHOW COLUMNS FROM `books` LIKE 'isbn'");
    if (!$res || $res->num_rows === 0) {
        $conn->query("ALTER TABLE `books` ADD COLUMN `isbn` VARCHAR(64) NULL");
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && (string)$_POST['action'] === 'create_book') {
    if (!$isAdmin) {
        header("Location: " . url('/pages/index.php'));
        exit;
    }

    if (!isset($conn) || !($conn instanceof mysqli)) {
        header("Location: " . url('/pages/index.php'));
        exit;
    }

    $title  = trim((string)($_POST['title'] ?? ''));
    $author = trim((string)($_POST['author'] ?? ''));
    $isbn   = trim((string)($_POST['isbn'] ?? ''));
    $genre  = trim((string)($_POST['genre'] ?? ''));

    if ($title === '' || $author === '' || $genre === '') {
        header("Location: " . url('/pages/index.php'));
        exit;
    }

    ensure_books_isbn_column($conn);

    $sql = "INSERT INTO books (title, author, genre, status, isbn) VALUES (?, ?, ?, 'available', ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssss", $title, $author, $genre, $isbn);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: " . url('/pages/index.php'));
    exit;
}


$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';

$hasIsbn = false;
if (isset($conn) && ($conn instanceof mysqli)) {
    $resCols = $conn->query("SHOW COLUMNS FROM `books` LIKE 'isbn'");
    if ($resCols && $resCols->num_rows > 0) $hasIsbn = true;
}

$booksRes = null;
$err = '';

if (!isset($conn) || !($conn instanceof mysqli)) {
    $err = 'Нет соединения с БД.';
} else {
    $fields = "id, title, author, genre, status" . ($hasIsbn ? ", isbn" : "");

    if ($q === '') {
        $sql = "SELECT $fields FROM books ORDER BY id DESC";
        $booksRes = $conn->query($sql);
    } else {
        $like = '%' . $q . '%';

        if ($hasIsbn) {
            $sql = "SELECT $fields FROM books
                    WHERE title LIKE ? OR author LIKE ? OR genre LIKE ? OR isbn LIKE ?
                    ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssss", $like, $like, $like, $like);
                $stmt->execute();
                $booksRes = $stmt->get_result();
                $stmt->close();
            } else {
                $err = 'Ошибка поиска.';
            }
        } else {
            $sql = "SELECT $fields FROM books
                    WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?
                    ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sss", $like, $like, $like);
                $stmt->execute();
                $booksRes = $stmt->get_result();
                $stmt->close();
            } else {
                $err = 'Ошибка поиска.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1206'); ?>" rel="stylesheet">

    <style>
        .catalog-toolbar{
            display:flex;
            align-items:center;
            gap:14px;
            width:100%;
            margin: 6px 0 14px 0;
        }
        .catalog-search{
            flex:1 1 auto;
            min-width:0;
            position:relative;
        }
        .catalog-search input{
            width:100%;
            height:42px;
            border-radius:14px;
            border:1px solid rgba(122,63,242,.22);
            padding:0 14px 0 42px;
            font-weight:900;
            outline:none;
            background:#fff;
        }
        .catalog-search .search-ico{
            position:absolute;
            left:14px;
            top:50%;
            transform:translateY(-50%);
            width:18px;height:18px;
            color:rgba(122,63,242,.9);
        }

        .add-book-btn{
            flex:0 0 auto;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            height:42px;
            padding:0 16px;
            border-radius:14px;
            background:#7a3ff2;
            color:#fff !important;
            font-weight:900;
            text-decoration:none !important;
            box-shadow:0 12px 26px rgba(122,63,242,.25);
            white-space:nowrap;
            border:0;
            cursor:pointer;
        }
        .add-book-btn:active{ transform: translateY(1px); }

        .book-card{
            background:#fff;
            border:1px solid rgba(122,63,242,.22);
            border-radius:18px;
            box-shadow:0 8px 22px rgba(17,24,39,.06);
            padding:12px;
            height:100%;
            cursor:pointer;
            transition:transform .15s ease, box-shadow .15s ease;
        }
        .book-card:hover{ transform:translateY(-2px); box-shadow:0 14px 30px rgba(17,24,39,.08); }

        .book-top{
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:10px;
            margin-bottom:10px;
        }
        .book-cover{
            width:44px;height:44px;
            border-radius:12px;
            object-fit:cover;
            border:1px solid rgba(122,63,242,.18);
            background:rgba(122,63,242,.08);
            flex:0 0 auto;
        }
        .status-pill{
            height:24px;
            padding:0 10px;
            border-radius:999px;
            font-weight:900;
            font-size:12px;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            white-space:nowrap;
        }
        .status-available{
            background:rgba(122,63,242,.14);
            color:#5b21b6;
            border:1px solid rgba(122,63,242,.25);
        }
        .status-issued{
            background:rgba(34,197,94,.12);
            color:#15803d;
            border:1px solid rgba(34,197,94,.22);
        }

        .book-title{
            font-weight:900;
            font-size:16px;
            color:#1f1633;
            margin-bottom:4px;
            line-height:1.2;
        }
        .book-author{
            font-weight:800;
            font-size:13px;
            color:rgba(31,22,51,.55);
            margin-bottom:10px;
        }
        .genre-pill{
            display:inline-flex;
            align-items:center;
            height:22px;
            padding:0 10px;
            border-radius:999px;
            background:rgba(122,63,242,.08);
            border:1px solid rgba(122,63,242,.18);
            color:#1f1633;
            font-weight:900;
            font-size:12px;
        }

        
        .modal-content{
            border-radius:18px;
            border:1px solid rgba(122,63,242,.20);
            box-shadow:0 22px 60px rgba(17,24,39,.16);
            overflow:hidden;
        }
        .book-modal-body{ padding:14px; }
        .book-modal-head{
            display:flex;
            justify-content:space-between;
            gap:12px;
            align-items:flex-start;
        }
        .book-modal-left{
            display:flex;
            gap:10px;
            align-items:flex-start;
        }
        .book-modal-cover{
            width:40px;height:40px;border-radius:12px;object-fit:cover;
            border:1px solid rgba(122,63,242,.18);
            background:rgba(122,63,242,.08);
            flex:0 0 auto;
        }
        .book-modal-title{ font-weight:900; font-size:17px; color:#1f1633; line-height:1.2; }
        .book-modal-author{ font-weight:800; font-size:12px; color:rgba(31,22,51,.55); margin-top:2px; }

        .book-modal-row{
            margin-top:10px;
            display:flex;
            gap:8px;
            flex-wrap:wrap;
            align-items:center;
        }
        .mstatus-pill{
            height:22px;
            padding:0 10px;
            border-radius:999px;
            font-weight:900;
            font-size:12px;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            white-space:nowrap;
        }
        .mstatus-available{
            background:#8b5cf6;
            color:#fff;
            border:1px solid rgba(122,63,242,.28);
        }
        .mstatus-issued{
            background:rgba(220,53,69,0.10);
            color:#b02a37;
            border:1px solid rgba(220,53,69,0.22);
        }
        .book-modal-isbn{
            width:100%;
            margin-top:10px;
            font-weight:900;
            font-size:12px;
            color:rgba(31,22,51,.45);
        }
        .book-modal-actions{ margin-top:12px; }

        .book-modal-form{
            width:100%;
            display:flex;
            align-items:center;
            gap:12px;
        }
        .book-modal-note{
            flex:0 0 48%;
            min-width:0;
            height:40px;
            border-radius:12px;
            border:1px solid rgba(122,63,242,.22);
            padding:0 12px;
            font-weight:900;
            outline:none;
            background:#fff;
        }
        .book-modal-btn{
            flex:1 1 auto;
            height:40px;
            border-radius:12px;
            border:none;
            background:#7a3ff2;
            color:#fff;
            font-weight:900;
            box-shadow:0 12px 26px rgba(122,63,242,.25);
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            cursor:pointer;
        }
        .book-modal-btn:disabled{ opacity:.6; cursor:not-allowed; box-shadow:none; }

        
        .add-modal-body{ padding:14px; }
        .add-head{
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:12px;
            margin-bottom:12px;
        }
        .add-left{
            display:flex;
            align-items:flex-start;
            gap:10px;
        }
        .add-ico{
            width:28px;height:28px;border-radius:10px;
            display:flex;align-items:center;justify-content:center;
            background:rgba(122,63,242,.12);
            color:#7a3ff2;
            border:1px solid rgba(122,63,242,.18);
            flex:0 0 auto;
            font-weight:900;
        }
        .add-title{
            font-weight:900;
            font-size:16px;
            color:#1f1633;
            line-height:1.2;
        }
        .add-sub{
            margin-top:3px;
            font-weight:800;
            font-size:12px;
            color:rgba(31,22,51,.55);
        }

        .adv-label{
            font-size:12px;
            font-weight:900;
            color:#111827;
            margin-bottom:6px;
        }
        .adv-input{
            border:1px solid rgba(122,63,242,.18);
            border-radius:12px;
            height:40px;
            font-size:14px;
            padding:10px 12px;
            background:#fff;
            font-weight:900;
        }
        .adv-input:focus{
            outline:none;
            box-shadow:none;
            border-color:rgba(122,63,242,.65);
        }

        .add-btn{
            width:100%;
            border:none;
            border-radius:12px;
            height:42px;
            background:#7A3FF2;
            color:#fff;
            font-weight:900;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            cursor:pointer;
            box-shadow:0 12px 26px rgba(122,63,242,.25);
            margin-top:10px;
        }
        .add-btn:active{ transform: translateY(1px); }

        .toastx{
            position:fixed;
            right:16px;
            bottom:16px;
            z-index:9999;
            background:#111827;
            color:#fff;
            padding:10px 12px;
            border-radius:12px;
            font-weight:900;
            box-shadow:0 16px 40px rgba(0,0,0,.22);
            opacity:0;
            transform:translateY(10px);
            transition:opacity .15s ease, transform .15s ease;
            pointer-events:none;
        }
        .toastx.show{ opacity:1; transform:translateY(0); }

        @media (max-width: 576px){
            .book-modal-form{ flex-direction:column; align-items:stretch; }
            .book-modal-note{ width:100%; }
            .book-modal-btn{ width:100%; }
        }
        @media (max-width: 768px){
            .catalog-toolbar{ flex-direction:column; align-items:stretch; }
            .add-book-btn{ width:100%; }
        }
    </style>
</head>

<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-2">
    <?php include('../includes/section_tabs.php'); ?>

    <div class="catalog-toolbar">
        <form class="catalog-search" method="GET" action="<?php echo url('/pages/index.php'); ?>">
            <span class="search-ico" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z" stroke="currentColor" stroke-width="2"/>
                    <path d="M16.2 16.2 21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </span>
            <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>"
                   placeholder="Найти книгу, автора или жанр...">
        </form>

        <?php if ($isAdmin) { ?>
            <button type="button" class="add-book-btn" data-toggle="modal" data-target="#addBookModal">
                ＋ Добавить книгу
            </button>
        <?php } ?>
    </div>

    <?php if ($err !== '') { ?>
        <div class="adv-empty" style="border-color: rgba(239,68,68,0.25); color: rgba(239,68,68,0.9);">
            <?php echo htmlspecialchars($err); ?>
        </div>
    <?php } else if (!$booksRes || $booksRes->num_rows === 0) { ?>
        <div class="adv-empty">Книги не найдены.</div>
    <?php } else { ?>
        <div class="row">
            <?php while ($row = $booksRes->fetch_assoc()) {
                $bookId = (int)$row['id'];
                $title = (string)$row['title'];
                $author = (string)$row['author'];
                $genre = (string)$row['genre'];
                $status = (string)$row['status'];
                $isbn = ($hasIsbn && isset($row['isbn'])) ? (string)$row['isbn'] : '';
            ?>
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="book-card js-book"
                         data-id="<?php echo $bookId; ?>"
                         data-title="<?php echo htmlspecialchars($title, ENT_QUOTES); ?>"
                         data-author="<?php echo htmlspecialchars($author, ENT_QUOTES); ?>"
                         data-genre="<?php echo htmlspecialchars($genre, ENT_QUOTES); ?>"
                         data-status="<?php echo htmlspecialchars($status, ENT_QUOTES); ?>"
                         data-isbn="<?php echo htmlspecialchars($isbn, ENT_QUOTES); ?>"
                         tabindex="0" role="button" aria-label="Открыть книгу">
                        <div class="book-top">
                            <img src="<?php echo url('/assets/images/f.jpg'); ?>" class="book-cover" alt="cover">

                            <?php if ($status === 'issued') { ?>
                                <span class="status-pill status-issued">Выдана</span>
                            <?php } else { ?>
                                <span class="status-pill status-available">Доступна</span>
                            <?php } ?>
                        </div>

                        <div class="book-title"><?php echo htmlspecialchars($title); ?></div>
                        <div class="book-author"><?php echo htmlspecialchars($author); ?></div>

                        <div>
                            <span class="genre-pill"><?php echo htmlspecialchars($genre); ?></span>
                        </div>

                        
                    </div>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
</div>


<div class="modal fade" id="bookModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:520px;">
    <div class="modal-content">
      <div class="book-modal-body">
        <div class="book-modal-head">
          <div class="book-modal-left">
            <img src="<?php echo url('/assets/images/f.jpg'); ?>" class="book-modal-cover" alt="cover">
            <div>
              <div class="book-modal-title" id="mTitle">Книга</div>
              <div class="book-modal-author" id="mAuthor">Автор</div>
            </div>
          </div>

          <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="opacity:.55;">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="book-modal-row">
          <span class="mstatus-pill mstatus-available" id="mStatus">Доступна</span>
          <span class="genre-pill" id="mGenre">Жанр</span>
        </div>

        <div class="book-modal-isbn" id="mIsbn" style="display:none;">ISBN: </div>

        <div class="book-modal-actions">
          <form method="POST" action="<?php echo url('/pages/borrow.php'); ?>" id="borrowForm" class="book-modal-form" style="margin:0;">
            <input type="hidden" name="book_id" id="mBookId" value="">
            <input type="text" name="note" id="mNote" class="book-modal-note" placeholder="" autocomplete="off">
            <button type="submit" class="book-modal-btn" id="mBorrowBtn">
              <span aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                  <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                </svg>
              </span>
              Взять книгу
            </button>
          </form>
        </div>

        <div id="mHint" style="margin-top:8px; font-weight:900; font-size:12px; color:rgba(31,22,51,.45); display:none;">
          Гость не может взять книгу. Войдите в аккаунт.
        </div>
      </div>
    </div>
  </div>
</div>


<?php if ($isAdmin) { ?>
<div class="modal fade" id="addBookModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:520px;">
    <div class="modal-content">
      <div class="add-modal-body">
        <div class="add-head">
          <div class="add-left">
            <div class="add-ico">＋</div>
            <div>
              <div class="add-title">Добавить книгу</div>
              <div class="add-sub">Заполните данные как в поиске</div>
            </div>
          </div>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="opacity:.55;">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form method="POST" action="<?php echo url('/pages/index.php'); ?>" style="margin:0;">
          <input type="hidden" name="action" value="create_book">

          <div class="row" style="margin-left:-8px;margin-right:-8px;">
            <div class="col-12 col-md-6" style="padding-left:8px;padding-right:8px;">
              <div class="adv-label">Название книги</div>
              <input type="text" name="title" class="form-control adv-input" placeholder="Например: 1984" required>
            </div>

            <div class="col-12 col-md-6 mt-3 mt-md-0" style="padding-left:8px;padding-right:8px;">
              <div class="adv-label">Автор</div>
              <input type="text" name="author" class="form-control adv-input" placeholder="Например: Оруэлл" required>
            </div>

            <div class="col-12 col-md-6 mt-3" style="padding-left:8px;padding-right:8px;">
              <div class="adv-label">ISBN</div>
              <input type="text" name="isbn" class="form-control adv-input" placeholder="978-5-17-098825-6">
            </div>

            <div class="col-12 col-md-6 mt-3" style="padding-left:8px;padding-right:8px;">
              <div class="adv-label">Жанр</div>
              <input type="text" name="genre" class="form-control adv-input" placeholder="Например: Фэнтези" required>
            </div>
          </div>

          <button class="add-btn" type="submit">
            <span aria-hidden="true">＋</span>
            Добавить книгу
          </button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>

<div class="toastx" id="toastx">Гость не может взять книгу</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
(function(){
  const isAuthorized = <?php echo $isAuthorized ? 'true' : 'false'; ?>;

  const modalEl = $('#bookModal');
  const mTitle = document.getElementById('mTitle');
  const mAuthor = document.getElementById('mAuthor');
  const mGenre = document.getElementById('mGenre');
  const mStatus = document.getElementById('mStatus');
  const mIsbn = document.getElementById('mIsbn');
  const mBookId = document.getElementById('mBookId');
  const mNote = document.getElementById('mNote');
  const mBorrowBtn = document.getElementById('mBorrowBtn');
  const mHint = document.getElementById('mHint');

  const toast = document.getElementById('toastx');
  let toastTimer = null;

  function showToast(text){
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1600);
  }

  function openBook(card){
    const id = card.dataset.id || '';
    const title = card.dataset.title || '';
    const author = card.dataset.author || '';
    const genre = card.dataset.genre || '';
    const status = card.dataset.status || '';
    const isbn = card.dataset.isbn || '';

    mBookId.value = id;
    if (mNote) { mNote.value = ''; }
    mTitle.textContent = title;
    mAuthor.textContent = author;
    mGenre.textContent = genre;

    if (isbn && isbn.trim() !== '') {
      mIsbn.style.display = 'block';
      mIsbn.textContent = 'ISBN: ' + isbn;
    } else {
      mIsbn.style.display = 'none';
      mIsbn.textContent = '';
    }

    if (status === 'issued') {
      mStatus.textContent = 'Выдана';
      mStatus.classList.remove('mstatus-available');
      mStatus.classList.add('mstatus-issued');
      mBorrowBtn.disabled = true;
      if (mNote) { mNote.disabled = true; }
      mHint.style.display = 'none';
    } else {
      mStatus.textContent = 'Доступна';
      mStatus.classList.remove('mstatus-issued');
      mStatus.classList.add('mstatus-available');
      mBorrowBtn.disabled = false;
      if (mNote) { mNote.disabled = false; }
      mHint.style.display = (!isAuthorized) ? 'block' : 'none';
    }

    modalEl.modal('show');
  }

  document.querySelectorAll('.js-book').forEach(card => {
    card.addEventListener('click', () => openBook(card));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openBook(card);
      }
    });
  });

  document.getElementById('borrowForm').addEventListener('submit', function(e){
    if (!isAuthorized) {
      e.preventDefault();
      showToast('Гость не может взять книгу');
    }
  });
})();
</script>

</body>
</html>