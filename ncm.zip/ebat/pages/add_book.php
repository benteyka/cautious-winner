<?php
include('../includes/config.php');
include('../includes/db.php');

include('../includes/header.php');
?>

<div class="container mt-4">
    <form action="add_book.php" method="POST">
        <div class="mb-3">
            <label for="title" class="form-label">Название книги</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3">
            <label for="author" class="form-label">Автор</label>
            <input type="text" class="form-control" id="author" name="author" required>
        </div>
        <div class="mb-3">
            <label for="genre" class="form-label">Жанр</label>
            <input type="text" class="form-control" id="genre" name="genre" required>
        </div>
        <button type="submit" class="btn btn-success">Добавить книгу</button>
    </form>
</div>

<?php

$footerPath = __DIR__ . '/../includes/footer.php';
if (file_exists($footerPath)) {
    include($footerPath);
}
?>
