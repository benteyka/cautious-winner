<?php
include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!defined('LOAN_DAYS')) {
    define('LOAN_DAYS', 14);
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$userId = 0;
if (!empty($_SESSION['user_id'])) $userId = (int)$_SESSION['user_id'];
else if (!empty($_SESSION['id'])) $userId = (int)$_SESSION['id'];
else if (!empty($_SESSION['user']['id'])) $userId = (int)$_SESSION['user']['id'];

$items = [];
$err = '';

function table_exists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function index_exists(mysqli $conn, string $table, string $indexName): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('ss', $table, $indexName);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function ensure_book_loans_schema(mysqli $conn): void {
    $conn->query(
        "CREATE TABLE IF NOT EXISTS `book_loans` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `book_id` int(11) NOT NULL,
            `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
            `due_at` datetime NOT NULL,
            `returned_at` datetime DEFAULT NULL,
            `processed_by` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_user_active` (`user_id`,`returned_at`),
            KEY `idx_book_active` (`book_id`,`returned_at`),
            KEY `idx_due_active` (`due_at`,`returned_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    );

    if (!index_exists($conn, 'book_loans', 'idx_user_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_user_active` (`user_id`,`returned_at`)");
    }
    if (!index_exists($conn, 'book_loans', 'idx_book_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_book_active` (`book_id`,`returned_at`)");
    }
    if (!index_exists($conn, 'book_loans', 'idx_due_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_due_active` (`due_at`,`returned_at`)");
    }
}


function migrate_issued_books_into_loans(mysqli $conn, int $loanDays): void {
    if (!table_exists($conn, 'books')) return;
    ensure_book_loans_schema($conn);
    if (!table_exists($conn, 'book_requests')) return;

    $sql = "
        SELECT b.id AS book_id
        FROM books b
        WHERE b.status='issued'
          AND NOT EXISTS (
              SELECT 1 FROM book_loans bl
              WHERE bl.book_id = b.id AND bl.returned_at IS NULL
          )
        ORDER BY b.id ASC
    ";
    $res = $conn->query($sql);
    if (!$res) return;

    while ($row = $res->fetch_assoc()) {
        $bookId = (int)$row['book_id'];

        $st = $conn->prepare("SELECT user_id, date_requested FROM book_requests WHERE book_id=? ORDER BY date_requested DESC, id DESC LIMIT 1");
        if (!$st) continue;
        $st->bind_param("i", $bookId);
        $st->execute();
        $rr = $st->get_result();
        $br = $rr ? $rr->fetch_assoc() : null;
        $st->close();

        if (!$br) continue;

        $userId = (int)$br['user_id'];
        $issuedAt = (string)$br['date_requested'];

        $st = $conn->prepare("INSERT INTO book_loans (user_id, book_id, issued_at, due_at, returned_at, processed_by)
                              VALUES (?, ?, ?, DATE_ADD(?, INTERVAL ? DAY), NULL, NULL)");
        if ($st) {
            $st->bind_param("iissi", $userId, $bookId, $issuedAt, $issuedAt, $loanDays);
            $st->execute();
            $st->close();
        }

        
        $st = $conn->prepare("DELETE FROM book_requests WHERE book_id=?");
        if ($st) {
            $st->bind_param("i", $bookId);
            $st->execute();
            $st->close();
        }
    }
}

if ($isAuthorized && $userId > 0) {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $err = 'Нет соединения с базой данных.';
    } else {
        ensure_book_loans_schema($conn);
        migrate_issued_books_into_loans($conn, max(1, (int)LOAN_DAYS));

        $sql = "
            SELECT
                b.id, b.title, b.author, b.genre,
                l.issued_at, l.due_at
            FROM book_loans l
            JOIN books b ON b.id = l.book_id
            WHERE l.user_id = ?
              AND l.returned_at IS NULL
            ORDER BY l.issued_at DESC, l.id DESC
        ";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $err = 'Ошибка запроса к базе.';
        } else {
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $items[] = $row;
                }
            }
            $stmt->close();
        }
    }
}

function fmt_date_ru(string $dt): string {
    $d = new DateTime($dt);
    return $d->format('d.m.Y');
}
function overdue_days_by_due(string $dueDt): int {
    $due = new DateTime($dueDt);
    $now = new DateTime();
    if ($now <= $due) return 0;
    $diff = $due->diff($now);
    return (int)$diff->days;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои книги</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1202'); ?>" rel="stylesheet">

    <style>
        .mybooks-list {
            display: flex;
            flex-direction: column;
            gap: 14px;
            padding-bottom: 20px;
        }

        .mybook-row {
            background: #ffffff;
            border: 1px solid rgba(122, 63, 242, 0.22);
            border-radius: 18px;
            box-shadow: 0 6px 22px rgba(17, 24, 39, 0.06);
            padding: 14px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .mybook-row.is-overdue {
            background: #fff5f5;
            border-color: rgba(239, 68, 68, 0.28);
            box-shadow: 0 10px 26px rgba(239, 68, 68, 0.08);
        }

        .mybook-left {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 0;
        }

        .mybook-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(122, 63, 242, 0.10);
            border: 1px solid rgba(122, 63, 242, 0.18);
            display: flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            overflow: hidden;
        }

        .mybook-icon img {
            width: 44px;
            height: 44px;
            object-fit: cover;
            display: block;
        }

        .mybook-info {
            min-width: 0;
        }

        .mybook-title {
            font-weight: 900;
            font-size: 16px;
            color: #1f1633;
            line-height: 1.2;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 680px;
        }

        .mybook-author {
            font-weight: 700;
            font-size: 13px;
            color: rgba(31, 22, 51, 0.55);
            margin-bottom: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 680px;
        }

        .mybook-dates {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            font-weight: 800;
            font-size: 12px;
            color: rgba(31, 22, 51, 0.55);
        }

        .date-item {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .date-ico {
            width: 16px;
            height: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: rgba(122, 63, 242, 0.85);
        }

        .mybook-right {
            flex: 0 0 auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 26px;
            padding: 0 12px;
            border-radius: 999px;
            font-weight: 900;
            font-size: 12px;
            white-space: nowrap;
            gap: 8px;
        }

        .pill-danger {
            background: #ef4444;
            color: #fff;
            border: 1px solid rgba(239, 68, 68, 0.35);
            box-shadow: 0 8px 18px rgba(239, 68, 68, 0.18);
        }

        .pill-success {
            background: rgba(34, 197, 94, 0.12);
            color: #15803d;
            border: 1px solid rgba(34, 197, 94, 0.22);
            box-shadow: 0 8px 18px rgba(34, 197, 94, 0.08);
        }

        .pill-ico {
            width: 14px;
            height: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        @media (max-width: 768px) {
            .mybook-row { flex-direction: column; align-items: flex-start; }
            .mybook-right { width: 100%; justify-content: flex-start; }
            .mybook-title, .mybook-author { max-width: 100%; }
        }
    </style>
</head>
<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-2">
    <?php $activeTab = 'my_books'; include('../includes/section_tabs.php'); ?>

    <?php if (!$isAuthorized) { ?>
        <div class="adv-empty">Войдите, чтобы видеть свои книги.</div>
    <?php } else if ($err !== '') { ?>
        <div class="adv-empty" style="border-color: rgba(239,68,68,0.25); color: rgba(239,68,68,0.9);">
            <?php echo htmlspecialchars($err); ?>
        </div>
    <?php } else if (count($items) === 0) { ?>
        <div class="adv-empty">Нет активных книг.</div>
    <?php } else { ?>

        <div class="mybooks-list">
            <?php foreach ($items as $it):
                $issuedAt = (string)$it['issued_at'];
                $dueAt = (string)$it['due_at'];
                $od = overdue_days_by_due($dueAt);
            ?>
                <div class="mybook-row <?php echo ($od > 0 ? 'is-overdue' : ''); ?>">
                    <div class="mybook-left">
                        <div class="mybook-icon">
                            <img src="<?php echo url('/assets/images/f.jpg'); ?>" alt="cover">
                        </div>

                        <div class="mybook-info">
                            <div class="mybook-title"><?php echo htmlspecialchars((string)$it['title']); ?></div>
                            <div class="mybook-author"><?php echo htmlspecialchars((string)$it['author']); ?></div>

                            <div class="mybook-dates">
                                <span class="date-item">
                                    <span class="date-ico" aria-hidden="true">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                            <path d="M8 7V3m8 4V3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                            <path d="M4 9h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                            <path d="M6 5h12a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="2"/>
                                        </svg>
                                    </span>
                                    С <?php echo htmlspecialchars(fmt_date_ru($issuedAt)); ?>
                                </span>

                                <span class="date-item">
                                    <span class="date-ico" aria-hidden="true">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                            <path d="M12 8v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" stroke="currentColor" stroke-width="2"/>
                                        </svg>
                                    </span>
                                    До <?php echo htmlspecialchars(fmt_date_ru($dueAt)); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="mybook-right">
                        <?php if ($od > 0) { ?>
                            <span class="pill pill-danger">
                                <span class="pill-ico" aria-hidden="true">!</span>
                                Просрочено <?php echo (int)$od; ?> дн.
                            </span>
                        <?php } else { ?>
                            <span class="pill pill-success">
                                <span class="pill-ico" aria-hidden="true">✓</span>
                                На руках
                            </span>
                        <?php } ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <?php } ?>
</div>

</body>
</html>