<?php
include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userRole = '';
if (!empty($_SESSION['user']['role'])) $userRole = (string)$_SESSION['user']['role'];
$isAdmin = (strtolower($userRole) === 'admin');

if (!$isAdmin) {
    header("Location: " . url('/pages/index.php'));
    exit;
}

$activeTab = 'manage';

$adminId = 0;
if (!empty($_SESSION['user_id'])) $adminId = (int)$_SESSION['user_id'];
else if (!empty($_SESSION['id'])) $adminId = (int)$_SESSION['id'];
else if (!empty($_SESSION['user']['id'])) $adminId = (int)$_SESSION['user']['id'];

$loanDaysDefault = defined('LOAN_DAYS') ? (int)LOAN_DAYS : 14;


$noticeOk = isset($_GET['ok']) ? (int)$_GET['ok'] : 0;
$noticeErr = isset($_GET['err']) ? (string)$_GET['err'] : '';

function initials_from_name(string $name): string {
    $name = trim($name);
    if ($name === '') return '??';
    $parts = preg_split('/\s+/u', $name);
    $first = $parts[0] ?? $name;
    $second = $parts[1] ?? '';
    $a = mb_substr($first, 0, 1, 'UTF-8');
    $b = $second !== '' ? mb_substr($second, 0, 1, 'UTF-8') : mb_substr($first, 1, 1, 'UTF-8');
    $res = mb_strtoupper(($a ?: '') . ($b ?: ''), 'UTF-8');
    return $res !== '' ? $res : '??';
}

function ticket_no(int $userId): string { return (string)(10000 + $userId); }

function table_exists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function index_exists(mysqli $conn, string $table, string $indexName): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('ss', $table, $indexName);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function column_exists(mysqli $conn, string $table, string $column): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND COLUMN_NAME = ?
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('ss', $table, $column);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function ensure_book_requests_schema(mysqli $conn): void {
    $conn->query(
        "CREATE TABLE IF NOT EXISTS `book_requests` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `book_id` int(11) NOT NULL,
            `date_requested` datetime DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `user_id` (`user_id`),
            KEY `book_id` (`book_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci"
    );
}

function ensure_book_loans_schema(mysqli $conn): void {
    $conn->query(
        "CREATE TABLE IF NOT EXISTS `book_loans` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `book_id` int(11) NOT NULL,
            `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
            `due_at` datetime NOT NULL,
            `returned_at` datetime DEFAULT NULL,
            `processed_by` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_user_active` (`user_id`,`returned_at`),
            KEY `idx_book_active` (`book_id`,`returned_at`),
            KEY `idx_due_active` (`due_at`,`returned_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    );

    if (table_exists($conn, 'book_loans') && !column_exists($conn, 'book_loans', 'processed_by')) {
        $conn->query("ALTER TABLE `book_loans` ADD COLUMN `processed_by` int(11) DEFAULT NULL");
    }

    if (!index_exists($conn, 'book_loans', 'idx_user_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_user_active` (`user_id`,`returned_at`)");
    }
    if (!index_exists($conn, 'book_loans', 'idx_book_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_book_active` (`book_id`,`returned_at`)");
    }
    if (!index_exists($conn, 'book_loans', 'idx_due_active')) {
        $conn->query("ALTER TABLE `book_loans` ADD KEY `idx_due_active` (`due_at`,`returned_at`)");
    }
}

function migrate_issued_books_into_loans(mysqli $conn, int $loanDays): void {
    if (!table_exists($conn, 'books')) return;
    if (!table_exists($conn, 'book_requests')) return;

    ensure_book_loans_schema($conn);

    $sql = "
        SELECT b.id AS book_id
        FROM books b
        WHERE b.status='issued'
          AND NOT EXISTS (
              SELECT 1 FROM book_loans bl
              WHERE bl.book_id = b.id AND bl.returned_at IS NULL
          )
        ORDER BY b.id ASC
    ";
    $res = $conn->query($sql);
    if (!$res) return;

    while ($row = $res->fetch_assoc()) {
        $bookId = (int)$row['book_id'];

        $st = $conn->prepare("SELECT user_id, date_requested FROM book_requests WHERE book_id=? ORDER BY date_requested DESC, id DESC LIMIT 1");
        if (!$st) continue;
        $st->bind_param("i", $bookId);
        $st->execute();
        $rr = $st->get_result();
        $br = $rr ? $rr->fetch_assoc() : null;
        $st->close();

        if (!$br) continue;

        $userId = (int)$br['user_id'];
        $issuedAt = (string)$br['date_requested'];

        $st = $conn->prepare("INSERT INTO book_loans (user_id, book_id, issued_at, due_at, returned_at, processed_by)
                              VALUES (?, ?, ?, DATE_ADD(?, INTERVAL ? DAY), NULL, NULL)");
        if ($st) {
            $st->bind_param("iissi", $userId, $bookId, $issuedAt, $issuedAt, $loanDays);
            $st->execute();
            $st->close();
        }

        $st = $conn->prepare("DELETE FROM book_requests WHERE book_id=?");
        if ($st) {
            $st->bind_param("i", $bookId);
            $st->execute();
            $st->close();
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? (string)$_POST['action'] : '';

    try {
        if (!isset($conn) || !($conn instanceof mysqli)) {
            throw new RuntimeException('Ошибка подключения к базе данных.');
        }

        ensure_book_requests_schema($conn);
        ensure_book_loans_schema($conn);

        if ($action === 'issue') {
            $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
            $bookId = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;

            if ($userId <= 0 || $bookId <= 0) {
                throw new RuntimeException('Некорректные данные выдачи.');
            }

            $conn->begin_transaction();

            $st = $conn->prepare("SELECT id FROM users WHERE id=? LIMIT 1");
            $st->bind_param("i", $userId);
            $st->execute();
            $ux = $st->get_result();
            $st->close();
            if (!$ux || $ux->num_rows === 0) {
                $conn->rollback();
                throw new RuntimeException('Пользователь не найден.');
            }

            $st = $conn->prepare("SELECT title, status FROM books WHERE id=? LIMIT 1");
            $st->bind_param("i", $bookId);
            $st->execute();
            $res = $st->get_result();
            $bk = $res ? $res->fetch_assoc() : null;
            $st->close();

            if (!$bk) {
                $conn->rollback();
                throw new RuntimeException('Книга не найдена.');
            }
            if ((string)$bk['status'] !== 'available') {
                $conn->rollback();
                throw new RuntimeException('Книга уже выдана.');
            }

            $st = $conn->prepare("SELECT id FROM book_requests WHERE user_id=? AND book_id=? ORDER BY date_requested DESC, id DESC LIMIT 1");
            $st->bind_param("ii", $userId, $bookId);
            $st->execute();
            $rr = $st->get_result();
            $rq = $rr ? $rr->fetch_assoc() : null;
            $st->close();

            if (!$rq) {
                $conn->rollback();
                throw new RuntimeException('Заявка на эту книгу не найдена.');
            }

            $st = $conn->prepare("SELECT id FROM book_loans WHERE book_id=? AND returned_at IS NULL LIMIT 1");
            $st->bind_param("i", $bookId);
            $st->execute();
            $rr = $st->get_result();
            $hasActive = ($rr && $rr->num_rows > 0);
            $st->close();

            if ($hasActive) {
                $conn->rollback();
                throw new RuntimeException('Книга уже выдана (активная выдача существует).');
            }

            $st = $conn->prepare("UPDATE books SET status='issued' WHERE id=? AND status='available'");
            $st->bind_param("i", $bookId);
            $st->execute();
            $aff = $st->affected_rows;
            $st->close();

            if ($aff <= 0) {
                $conn->rollback();
                throw new RuntimeException('Не удалось выдать книгу (статус изменился).');
            }

            $days = max(1, (int)$loanDaysDefault);
            $st = $conn->prepare("INSERT INTO book_loans (user_id, book_id, issued_at, due_at, returned_at, processed_by)
                                  VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? DAY), NULL, ?)");
            $st->bind_param("iiii", $userId, $bookId, $days, $adminId);
            $st->execute();
            $st->close();

            $st = $conn->prepare("DELETE FROM book_requests WHERE user_id=? AND book_id=?");
            $st->bind_param("ii", $userId, $bookId);
            $st->execute();
            $st->close();

            if (table_exists($conn, 'notifications')) {
                $msg = 'Вам выдана книга "' . (string)$bk['title'] . '".';
                $st = $conn->prepare("INSERT INTO notifications (user_id, message, date_created) VALUES (?, ?, NOW())");
                $st->bind_param("is", $userId, $msg);
                $st->execute();
                $st->close();
            }

            $conn->commit();
            header("Location: " . url('/pages/manage.php?ok=1'));
            exit;
        }

        if ($action === 'extend') {
            $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
            $bookId = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;
            $days   = isset($_POST['days']) ? (int)$_POST['days'] : $loanDaysDefault;

            if ($userId <= 0 || $bookId <= 0) throw new RuntimeException('Некорректные данные продления.');

            if ($days < 1) $days = 1;
            if ($days > 365) $days = 365;

            $conn->begin_transaction();

            $sql = "
                UPDATE book_loans
                SET due_at = DATE_ADD(GREATEST(due_at, NOW()), INTERVAL ? DAY),
                    processed_by = ?
                WHERE user_id = ?
                  AND book_id = ?
                  AND returned_at IS NULL
                ORDER BY issued_at DESC, id DESC
                LIMIT 1
            ";
            $st = $conn->prepare($sql);
            $st->bind_param("iiii", $days, $adminId, $userId, $bookId);
            $st->execute();
            $aff = $st->affected_rows;
            $st->close();

            if ($aff <= 0) {
                $conn->rollback();
                throw new RuntimeException('Не удалось продлить срок (активная выдача не найдена).');
            }

            $conn->commit();
            header("Location: " . url('/pages/manage.php?ok=2'));
            exit;
        }

        if ($action === 'return') {
            $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
            $bookId = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;
            if ($userId <= 0 || $bookId <= 0) throw new RuntimeException('Некорректные данные приёма.');

            $conn->begin_transaction();

            $st = $conn->prepare("
                UPDATE book_loans
                SET returned_at = NOW(),
                    processed_by = ?
                WHERE user_id = ?
                  AND book_id = ?
                  AND returned_at IS NULL
                ORDER BY issued_at DESC, id DESC
                LIMIT 1
            ");
            $st->bind_param("iii", $adminId, $userId, $bookId);
            $st->execute();
            $aff = $st->affected_rows;
            $st->close();

            if ($aff <= 0) {
                $conn->rollback();
                throw new RuntimeException('Не удалось принять книгу (активная выдача не найдена).');
            }

            $st = $conn->prepare("UPDATE books SET status='available' WHERE id=?");
            $st->bind_param("i", $bookId);
            $st->execute();
            $st->close();

            if (table_exists($conn, 'notifications')) {
                $st = $conn->prepare("SELECT title FROM books WHERE id=? LIMIT 1");
                $st->bind_param("i", $bookId);
                $st->execute();
                $res = $st->get_result();
                $bk = $res ? $res->fetch_assoc() : null;
                $st->close();

                $msg = 'Книга "' . (($bk && isset($bk['title'])) ? (string)$bk['title'] : 'Книга') . '" принята обратно.';
                $st = $conn->prepare("INSERT INTO notifications (user_id, message, date_created) VALUES (?, ?, NOW())");
                $st->bind_param("is", $userId, $msg);
                $st->execute();
                $st->close();
            }

            $conn->commit();
            header("Location: " . url('/pages/manage.php?ok=3'));
            exit;
        }

    } catch (Throwable $e) {
        header("Location: " . url('/pages/manage.php?err=' . urlencode($e->getMessage())));
        exit;
    }
}


$users = [];
$statsTotal = 0;
$statsIssued = 0;
$statsOverdue = 0;

$loansByUser = [];
$reqsByUser = [];

$hasIsbn = false;
if (isset($conn) && ($conn instanceof mysqli)) {
    $rc = $conn->query("SHOW COLUMNS FROM `books` LIKE 'isbn'");
    if ($rc && $rc->num_rows > 0) $hasIsbn = true;
}

try {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        throw new RuntimeException('Ошибка подключения к базе данных.');
    }

    ensure_book_requests_schema($conn);
    ensure_book_loans_schema($conn);
    migrate_issued_books_into_loans($conn, max(1, (int)$loanDaysDefault));

    $res = $conn->query("SELECT id, username, role FROM users WHERE role IN ('reader','admin') ORDER BY username ASC");
    while ($res && ($row = $res->fetch_assoc())) {
        $users[] = [
            'id' => (int)$row['id'],
            'username' => (string)$row['username'],
            'role' => (string)$row['role'],
        ];
    }

    $r = $conn->query("SELECT COUNT(*) AS c FROM books");
    if ($r && ($row = $r->fetch_assoc())) $statsTotal = (int)$row['c'];

    $r = $conn->query("SELECT COUNT(*) AS c FROM books WHERE status='issued'");
    if ($r && ($row = $r->fetch_assoc())) $statsIssued = (int)$row['c'];

    $r = $conn->query("SELECT COUNT(*) AS c FROM book_loans WHERE returned_at IS NULL AND due_at < NOW()");
    if ($r && ($row = $r->fetch_assoc())) $statsOverdue = (int)$row['c'];

    $sqlLoans = "
        SELECT
            l.user_id,
            l.book_id,
            l.issued_at,
            l.due_at,
            b.title,
            b.author,
            b.genre,
            GREATEST(DATEDIFF(NOW(), l.due_at), 0) AS overdue_days
        FROM book_loans l
        JOIN books b ON b.id = l.book_id
        WHERE l.returned_at IS NULL
        ORDER BY l.user_id ASC, l.issued_at DESC, l.id DESC
    ";
    $resLoans = $conn->query($sqlLoans);
    while ($resLoans && ($row = $resLoans->fetch_assoc())) {
        $uid = (int)$row['user_id'];
        if (!isset($loansByUser[$uid])) $loansByUser[$uid] = [];
        $loansByUser[$uid][] = [
            'book_id' => (int)$row['book_id'],
            'title' => (string)$row['title'],
            'author' => (string)$row['author'],
            'genre' => (string)$row['genre'],
            'issued_at' => (string)$row['issued_at'],
            'due_at' => (string)$row['due_at'],
            'overdue_days' => (int)$row['overdue_days'],
        ];
    }

    $fieldsIsbn = $hasIsbn ? ", b.isbn" : "";
    $sqlReq = "
        SELECT
            br.id AS req_id,
            br.user_id,
            br.book_id,
            br.date_requested,
            b.title,
            b.author,
            b.genre
            {$fieldsIsbn}
        FROM book_requests br
        JOIN (
            SELECT
                user_id,
                book_id,
                MAX(CONCAT(DATE_FORMAT(date_requested,'%Y-%m-%d %H:%i:%s'),'#',LPAD(id,10,'0'))) AS mx
            FROM book_requests
            GROUP BY user_id, book_id
        ) m
          ON m.user_id = br.user_id
         AND m.book_id = br.book_id
         AND m.mx = CONCAT(DATE_FORMAT(br.date_requested,'%Y-%m-%d %H:%i:%s'),'#',LPAD(br.id,10,'0'))
        JOIN books b ON b.id = br.book_id
        WHERE b.status='available'
        ORDER BY br.date_requested DESC, br.id DESC
    ";
    $resReq = $conn->query($sqlReq);
    while ($resReq && ($row = $resReq->fetch_assoc())) {
        $uid = (int)$row['user_id'];
        if (!isset($reqsByUser[$uid])) $reqsByUser[$uid] = [];
        $reqsByUser[$uid][] = [
            'req_id' => (int)$row['req_id'],
            'book_id' => (int)$row['book_id'],
            'title' => (string)$row['title'],
            'author' => (string)$row['author'],
            'genre' => (string)$row['genre'],
            'isbn' => ($hasIsbn && isset($row['isbn'])) ? (string)$row['isbn'] : '',
        ];
    }

} catch (Throwable $e) {
    
}

$jsReqMap = [];
$jsNameMap = [];
foreach ($users as $u) {
    $uid = (int)$u['id'];
    $jsReqMap[(string)$uid] = $reqsByUser[$uid] ?? [];
    $jsNameMap[(string)$uid] = (string)$u['username'];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1502'); ?>" rel="stylesheet">

    <style>
        .m-stats{ display:grid; grid-template-columns: 1fr 1fr 1fr; gap:14px; margin-bottom:14px; }
        .m-stat{ background:#fff; border:1px solid rgba(122,63,242,.18); border-radius:18px; box-shadow:0 6px 22px rgba(122,63,242,.08); padding:14px 16px; }
        .m-stat-label{ font-weight:900; font-size:12px; color:rgba(31,22,51,.60); margin-bottom:4px; }
        .m-stat-value{ font-weight:900; font-size:28px; color:#7a3ff2; line-height:1; }
        .m-stat.m-danger{ background: rgba(239,68,68,.06); border-color: rgba(239,68,68,.18); }
        .m-stat.m-danger .m-stat-value{ color:#ef4444; }

        .m-card{ background:#fff; border:1px solid rgba(122,63,242,.18); border-radius:18px; box-shadow:0 6px 22px rgba(122,63,242,.08); padding:16px; }
        .m-head{ display:flex; align-items:flex-start; gap:12px; margin-bottom:14px; }
        .m-ico{ width:34px;height:34px;border-radius:12px; display:flex;align-items:center;justify-content:center; background:rgba(122,63,242,.12); color:#7a3ff2; flex:0 0 auto; }
        .m-title{ font-weight:900; font-size:18px; color:#1f1633; line-height:1.2; }
        .m-sub{ margin-top:4px; font-size:12px; color:rgba(31,22,51,.55); font-weight:700; }

        .u-block{ border:1px solid rgba(122,63,242,.14); border-radius:16px; overflow:hidden; margin-bottom:12px; }
        .u-top{ display:flex; align-items:center; justify-content:space-between; gap:12px; padding:14px; background:#fff; }
        .u-left{ display:flex; align-items:center; gap:12px; min-width:0; }
        .u-avatar{ width:40px;height:40px;border-radius:999px; display:flex;align-items:center;justify-content:center; background:rgba(122,63,242,.12); color:#7a3ff2; border:1px solid rgba(122,63,242,.18); font-weight:900; letter-spacing:.4px; flex:0 0 auto; }
        .u-meta{ min-width:0; }
        .u-name{ font-weight:900; font-size:14px; color:#1f1633; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .u-ticket{ font-weight:800; font-size:12px; color:rgba(31,22,51,.55); margin-top:2px; display:flex; gap:8px; align-items:center; flex-wrap:wrap; }

        .role-chip{
            display:inline-flex; align-items:center; justify-content:center;
            height:18px; padding:0 8px; border-radius:999px;
            font-weight:900; font-size:11px;
            border:1px solid rgba(122,63,242,.18);
            background:rgba(122,63,242,.08);
            color:#1f1633;
        }
        .role-chip.admin{
            border-color: rgba(239,68,68,.22);
            background: rgba(239,68,68,.08);
            color:#b91c1c;
        }

        .u-issue-btn{
            display:inline-flex; align-items:center; gap:8px;
            height:32px; padding:0 12px; border-radius:12px;
            border:1px solid rgba(31,22,51,.10);
            background:#fff; color:rgba(31,22,51,.75);
            font-weight:900; font-size:13px;
            cursor:pointer; transition: all .12s ease; white-space:nowrap;
        }
        .u-issue-btn:hover{ background:rgba(122,63,242,.06); border-color:rgba(122,63,242,.18); color:#1f1633; }
        .u-issue-btn:disabled{ opacity:.45; cursor:not-allowed; background:#fff; }

        .u-body{ padding:12px 14px 14px; background:rgba(122,63,242,.03); border-top:1px solid rgba(122,63,242,.10); }
        .u-sec{ font-weight:900; font-size:12px; color:rgba(31,22,51,.55); margin-bottom:10px; }

        .loan-row{
            display:flex; align-items:center; justify-content:space-between; gap:12px;
            padding:10px 10px; border-radius:14px; background:#fff;
            border:1px solid rgba(122,63,242,.10); margin-bottom:8px;
        }
        .loan-left{ display:flex; align-items:flex-start; gap:10px; min-width:0; }
        .loan-ico{ width:28px;height:28px;border-radius:8px; display:flex;align-items:center;justify-content:center; background:rgba(122,63,242,.10); border:1px solid rgba(122,63,242,.14); flex:0 0 auto; color:#7a3ff2; }
        .loan-meta{ min-width:0; }
        .loan-title{ font-weight:900; font-size:13px; color:#1f1633; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .loan-sub{ margin-top:2px; font-weight:800; font-size:12px; color:rgba(31,22,51,.55); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .loan-sub .over{ color:#ef4444; font-weight:900; }

        .loan-actions{ display:flex; align-items:center; gap:10px; flex:0 0 auto; }
        .icon-btn{
            width:30px;height:30px;border-radius:999px;
            border:1px solid rgba(31,22,51,.10); background:#fff;
            display:inline-flex; align-items:center; justify-content:center;
            cursor:pointer; transition: all .12s ease;
        }
        .icon-btn:hover{ background:rgba(122,63,242,.06); border-color:rgba(122,63,242,.18); }
        .icon-btn svg{ width:16px;height:16px; }
        .icon-btn.extend{ color:#7a3ff2; }
        .icon-btn.return{ color:#22c55e; }

        .u-empty{ font-weight:800; font-size:12px; color:rgba(31,22,51,.45); padding:10px 2px 2px; }

        
        .issue-modal-head{
            padding:14px 16px 10px;
            border-bottom:1px solid rgba(122,63,242,.10);
            display:flex; align-items:flex-start; justify-content:space-between; gap:12px;
        }
        .issue-title-row{ display:flex; gap:10px; align-items:flex-start; }
        .issue-plus{
            width:28px;height:28px;border-radius:10px;
            display:flex;align-items:center;justify-content:center;
            background:rgba(122,63,242,.12);
            color:#7a3ff2;
            border:1px solid rgba(122,63,242,.18);
            flex:0 0 auto;
            font-weight:900;
        }
        .issue-title{ font-weight:900; font-size:14px; color:#1f1633; line-height:1.2; }
        .issue-sub{ margin-top:4px; font-weight:800; font-size:12px; color:rgba(31,22,51,.55); }
        .issue-close{
            width:30px;height:30px;border-radius:999px;
            border:1px solid rgba(31,22,51,.10);
            background:#fff; color:rgba(31,22,51,.55);
            display:inline-flex; align-items:center; justify-content:center;
            cursor:pointer;
        }
        .issue-body{ padding:12px 16px 16px; }
        .pick-grid{ display:grid; grid-template-columns: 1fr 1fr; gap:12px; }
        @media (max-width: 520px){ .pick-grid{ grid-template-columns: 1fr; } }

        .pick-card{
            width:100%;
            text-align:left;
            background:#fff;
            border:1px solid rgba(122,63,242,.18);
            border-radius:16px;
            padding:12px;
            box-shadow:0 8px 22px rgba(17,24,39,.06);
            cursor:pointer;
            transition:transform .12s ease, box-shadow .12s ease, border-color .12s ease;
        }
        .pick-card:hover{
            transform:translateY(-1px);
            box-shadow:0 14px 30px rgba(17,24,39,.08);
            border-color: rgba(122,63,242,.26);
        }
        .pick-top{ display:flex; align-items:flex-start; justify-content:space-between; gap:10px; }
        .pick-left{ display:flex; gap:10px; align-items:flex-start; min-width:0; }
        .pick-cover{
            width:36px;height:36px;border-radius:12px; object-fit:cover;
            border:1px solid rgba(122,63,242,.18);
            background:rgba(122,63,242,.08);
            flex:0 0 auto;
        }
        .pick-info{ min-width:0; }
        .pick-title{
            font-weight:900; font-size:14px; color:#1f1633;
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
        }
        .pick-author{
            margin-top:2px;
            font-weight:800; font-size:12px; color:rgba(31,22,51,.55);
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
        }
        .pick-row{ margin-top:10px; display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
        .genre-pill{
            display:inline-flex;
            align-items:center;
            height:22px;
            padding:0 10px;
            border-radius:999px;
            background:rgba(122,63,242,.08);
            border:1px solid rgba(122,63,242,.18);
            color:#1f1633;
            font-weight:900;
            font-size:12px;
        }
        .isbn-line{
            width:100%;
            margin-top:6px;
            font-weight:900;
            font-size:12px;
            color:rgba(31,22,51,.45);
        }
        .pick-badge{
            width:18px;height:18px;border-radius:999px;
            border:1px solid rgba(31,22,51,.12);
            background:#fff;
            flex:0 0 auto;
            display:flex;align-items:center;justify-content:center;
            color:rgba(31,22,51,.35);
        }
        .pick-card:hover .pick-badge{ border-color: rgba(122,63,242,.26); color:#7a3ff2; }

        
        .ext-head{
            padding:14px 16px 12px;
            border-bottom:1px solid rgba(122,63,242,.10);
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:12px;
        }
        .ext-left{
            display:flex;
            align-items:flex-start;
            gap:10px;
        }
        .ext-ico{
            width:28px;height:28px;border-radius:10px;
            display:flex;align-items:center;justify-content:center;
            background:rgba(122,63,242,.12);
            color:#7a3ff2;
            border:1px solid rgba(122,63,242,.18);
            flex:0 0 auto;
        }
        .ext-title{
            font-weight:900;
            font-size:14px;
            color:#1f1633;
            line-height:1.2;
        }
        .ext-sub{
            margin-top:4px;
            font-weight:800;
            font-size:12px;
            color:rgba(31,22,51,.55);
        }
        .ext-close{
            width:30px;height:30px;border-radius:999px;
            border:1px solid rgba(31,22,51,.10);
            background:#fff; color:rgba(31,22,51,.55);
            display:inline-flex; align-items:center; justify-content:center;
            cursor:pointer;
        }
        .ext-body{
            padding:14px 16px 16px;
            background:#fff;
        }
        .ext-book{
            background:rgba(122,63,242,.08);
            border:1px solid rgba(122,63,242,.12);
            border-radius:14px;
            padding:12px;
            display:flex;
            gap:10px;
            align-items:center;
            margin-bottom:12px;
        }
        .ext-book-ico{
            width:34px;height:34px;border-radius:12px;
            background:#fff;
            border:1px solid rgba(122,63,242,.14);
            display:flex;align-items:center;justify-content:center;
            color:#7a3ff2;
            flex:0 0 auto;
        }
        .ext-book-title{
            font-weight:900;
            font-size:13px;
            color:#1f1633;
            line-height:1.2;
        }
        .ext-book-author{
            margin-top:2px;
            font-weight:800;
            font-size:12px;
            color:rgba(31,22,51,.55);
        }
        .ext-label{
            font-weight:900;
            font-size:12px;
            color:rgba(31,22,51,.75);
            margin:10px 0 6px;
        }
        .ext-input{
            height:44px;
            border-radius:14px;
            border:1px solid rgba(122,63,242,.28);
            font-weight:900;
            box-shadow:none;
        }
        .ext-actions{
            margin-top:14px;
            display:flex;
            gap:12px;
        }
        .btn-soft{
            flex:1 1 auto;
            height:44px;
            border-radius:14px;
            border:1px solid rgba(31,22,51,.12);
            background:#fff;
            font-weight:900;
            color:rgba(31,22,51,.75);
        }
        .btn-primaryx{
            flex:1 1 auto;
            height:44px;
            border-radius:14px;
            border:0;
            background:#8b5cf6;
            color:#fff;
            font-weight:900;
            box-shadow:0 10px 26px rgba(139,92,246,.28);
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:10px;
        }
        .btn-primaryx:active{ transform: translateY(1px); }

        @media (max-width: 900px){ .m-stats{ grid-template-columns: 1fr; } }
    </style>
</head>
<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-2">
    <?php include('../includes/section_tabs.php'); ?>

    <div class="m-stats">
        <div class="m-stat">
            <div class="m-stat-label">Всего книг</div>
            <div class="m-stat-value"><?php echo (int)$statsTotal; ?></div>
        </div>
        <div class="m-stat">
            <div class="m-stat-label">Выдано</div>
            <div class="m-stat-value"><?php echo (int)$statsIssued; ?></div>
        </div>
        <div class="m-stat m-danger">
            <div class="m-stat-label">Просрочено</div>
            <div class="m-stat-value"><?php echo (int)$statsOverdue; ?></div>
        </div>
    </div>

    <div class="m-card">
        <div class="m-head">
            <div class="m-ico" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0Z" stroke="currentColor" stroke-width="2"/>
                    <path d="M4 20a8 8 0 0 1 16 0" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </div>
            <div>
                <div class="m-title">Управление пользователями</div>
                <div class="m-sub">Выдавайте, принимайте и продлевайте книги</div>
            </div>
        </div>

        <?php if (count($users) === 0) { ?>
            <div class="u-empty">Пользователей пока нет.</div>
        <?php } ?>

        <?php foreach ($users as $u):
            $uid = (int)$u['id'];
            $uname = (string)$u['username'];
            $role = strtolower((string)$u['role']);
            $roleLabel = ($role === 'admin') ? 'Админ' : 'Читатель';

            $ini = initials_from_name($uname);
            $tno = ticket_no($uid);

            $loans = $loansByUser[$uid] ?? [];
            $reqs  = $reqsByUser[$uid] ?? [];
            $canIssue = count($reqs) > 0;
        ?>
            <div class="u-block">
                <div class="u-top">
                    <div class="u-left">
                        <div class="u-avatar"><?php echo htmlspecialchars($ini); ?></div>
                        <div class="u-meta">
                            <div class="u-name"><?php echo htmlspecialchars($uname); ?></div>
                            <div class="u-ticket">
                                Билет №<?php echo htmlspecialchars($tno); ?>
                                <span class="role-chip <?php echo ($role === 'admin') ? 'admin' : ''; ?>">
                                    <?php echo htmlspecialchars($roleLabel); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <button type="button"
                            class="u-issue-btn js-open-issue"
                            data-user="<?php echo $uid; ?>"
                            <?php echo $canIssue ? '' : 'disabled'; ?>>
                        <span aria-hidden="true" style="width:16px;height:16px;display:inline-flex;align-items:center;justify-content:center;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        Выдать
                    </button>
                </div>

                <div class="u-body">
                    <div class="u-sec">Активные книги</div>

                    <?php if (count($loans) === 0) { ?>
                        <div class="u-empty">Нет активных книг</div>
                    <?php } else { ?>
                        <?php foreach ($loans as $ln):
                            $bid = (int)$ln['book_id'];
                            $due = (string)$ln['due_at'];
                            $dueStr = $due ? date('d.m.Y', strtotime($due)) : '';
                            $od = (int)$ln['overdue_days'];
                        ?>
                            <div class="loan-row">
                                <div class="loan-left">
                                    <div class="loan-ico" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none">
                                            <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                            <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                                        </svg>
                                    </div>
                                    <div class="loan-meta">
                                        <div class="loan-title"><?php echo htmlspecialchars($ln['title']); ?></div>
                                        <div class="loan-sub">
                                            До <?php echo htmlspecialchars($dueStr); ?>
                                            <?php if ($od > 0) { ?>
                                                <span class="over"> • Просрочено <?php echo $od; ?> дн.</span>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="loan-actions">
                                    <button
                                        class="icon-btn extend js-open-extend"
                                        type="button"
                                        title="Продлить срок чтения"
                                        data-user="<?php echo $uid; ?>"
                                        data-book="<?php echo $bid; ?>"
                                        data-title="<?php echo htmlspecialchars($ln['title'], ENT_QUOTES); ?>"
                                        data-author="<?php echo htmlspecialchars($ln['author'], ENT_QUOTES); ?>"
                                    >
                                        <svg viewBox="0 0 24 24" fill="none">
                                            <path d="M12 8v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" stroke="currentColor" stroke-width="2"/>
                                        </svg>
                                    </button>

                                    <form method="POST" action="<?php echo url('/pages/manage.php'); ?>" style="margin:0;">
                                        <input type="hidden" name="action" value="return">
                                        <input type="hidden" name="user_id" value="<?php echo $uid; ?>">
                                        <input type="hidden" name="book_id" value="<?php echo $bid; ?>">
                                        <button class="icon-btn return" type="submit" title="Принять книгу">
                                            <svg viewBox="0 0 24 24" fill="none">
                                                <path d="M20 6 9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php } ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>


<div class="modal fade" id="issueModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:560px;">
    <div class="modal-content" style="border-radius:18px;border:1px solid rgba(122,63,242,.18);overflow:hidden;">
        <div class="issue-modal-head">
            <div class="issue-title-row">
                <div class="issue-plus">＋</div>
                <div>
                    <div class="issue-title" id="issueTitle">Выдать книгу</div>
                    <div class="issue-sub" id="issueSub">Выберите книгу из заявок пользователя</div>
                </div>
            </div>
            <button class="issue-close" type="button" data-dismiss="modal" aria-label="Close">✕</button>
        </div>

        <div class="issue-body">
            <div class="pick-grid" id="pickGrid"></div>

            <div class="u-empty" id="pickEmpty" style="display:none; padding:10px 0 0;">
                У пользователя нет доступных заявок
            </div>

            <form method="POST" action="<?php echo url('/pages/manage.php'); ?>" id="issueForm" style="display:none;">
                <input type="hidden" name="action" value="issue">
                <input type="hidden" name="user_id" id="fUserId" value="">
                <input type="hidden" name="book_id" id="fBookId" value="">
            </form>
        </div>
    </div>
  </div>
</div>


<div class="modal fade" id="extendModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:520px;">
    <div class="modal-content" style="border-radius:18px;border:1px solid rgba(122,63,242,.18);overflow:hidden;">
        <div class="ext-head">
            <div class="ext-left">
                <div class="ext-ico" aria-hidden="true">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M12 8v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" stroke="currentColor" stroke-width="2"/>
                    </svg>
                </div>
                <div>
                    <div class="ext-title" id="extTitle">Продлить срок</div>
                    <div class="ext-sub" id="extSub">Продление срока возврата для</div>
                </div>
            </div>
            <button class="ext-close" type="button" data-dismiss="modal" aria-label="Close">✕</button>
        </div>

        <div class="ext-body">
            <div class="ext-book">
                <div class="ext-book-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div>
                    <div class="ext-book-title" id="extBookTitle">Книга</div>
                    <div class="ext-book-author" id="extBookAuthor">Автор</div>
                </div>
            </div>

            <form method="POST" action="<?php echo url('/pages/manage.php'); ?>" id="extendForm" style="margin:0;">
                <input type="hidden" name="action" value="extend">
                <input type="hidden" name="user_id" id="extUserId" value="">
                <input type="hidden" name="book_id" id="extBookId" value="">

                <div class="ext-label">Продлить на (дней)</div>
                <input
                    type="number"
                    min="1"
                    max="365"
                    step="1"
                    class="form-control ext-input"
                    name="days"
                    id="extDays"
                    value="<?php echo (int)$loanDaysDefault; ?>"
                >

                <div class="ext-actions">
                    <button type="button" class="btn-soft" data-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn-primaryx">
                        <span aria-hidden="true" style="width:16px;height:16px;display:inline-flex;align-items:center;justify-content:center;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <path d="M12 8v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" stroke="currentColor" stroke-width="2"/>
                            </svg>
                        </span>
                        Продлить
                    </button>
                </div>
            </form>
        </div>
    </div>
  </div>
</div>

<script>
window.MANAGE_REQS = <?php echo json_encode($jsReqMap, JSON_UNESCAPED_UNICODE); ?>;
window.MANAGE_NAMES = <?php echo json_encode($jsNameMap, JSON_UNESCAPED_UNICODE); ?>;
window.HAS_ISBN = <?php echo $hasIsbn ? 'true' : 'false'; ?>;
window.DEFAULT_EXT_DAYS = <?php echo (int)$loanDaysDefault; ?>;
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
(function(){
    const reqsMap = window.MANAGE_REQS || {};
    const nameMap = window.MANAGE_NAMES || {};
    const hasIsbn = !!window.HAS_ISBN;
    const defaultExtDays = parseInt(window.DEFAULT_EXT_DAYS || 14, 10) || 14;

    
    const issueModal = $('#issueModal');
    const pickGrid = document.getElementById('pickGrid');
    const pickEmpty = document.getElementById('pickEmpty');
    const issueTitle = document.getElementById('issueTitle');

    const fUserId = document.getElementById('fUserId');
    const fBookId = document.getElementById('fBookId');
    const issueForm = document.getElementById('issueForm');

    function esc(s){
        return String(s || '')
            .replaceAll('&','&amp;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;')
            .replaceAll('"','&quot;')
            .replaceAll("'","&#039;");
    }

    function renderIssueCards(userId){
        const list = reqsMap[String(userId)] || [];
        pickGrid.innerHTML = '';
        pickEmpty.style.display = list.length ? 'none' : 'block';

        list.forEach((it) => {
            const isbn = (hasIsbn && it.isbn) ? String(it.isbn) : '';
            const html = `
                <button type="button" class="pick-card" data-book="${esc(it.book_id)}">
                    <div class="pick-top">
                        <div class="pick-left">
                            <img class="pick-cover" src="<?php echo url('/assets/images/f.jpg'); ?>" alt="cover">
                            <div class="pick-info">
                                <div class="pick-title">${esc(it.title)}</div>
                                <div class="pick-author">${esc(it.author)}</div>
                            </div>
                        </div>
                        <div class="pick-badge" aria-hidden="true">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                                <path d="M20 6 9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                    </div>

                    <div class="pick-row">
                        <span class="genre-pill">${esc(it.genre)}</span>
                    </div>

                    ${isbn ? `<div class="isbn-line">ISBN: ${esc(isbn)}</div>` : ``}
                </button>
            `;
            pickGrid.insertAdjacentHTML('beforeend', html);
        });
    }

    document.querySelectorAll('.js-open-issue').forEach(btn => {
        btn.addEventListener('click', function(){
            const userId = this.getAttribute('data-user');
            const uname = nameMap[String(userId)] || 'Пользователь';
            issueTitle.textContent = 'Выдать книгу: ' + uname;

            fUserId.value = userId;
            fBookId.value = '';

            renderIssueCards(userId);
            issueModal.modal('show');
        });
    });

    pickGrid.addEventListener('click', function(e){
        const card = e.target.closest('.pick-card');
        if (!card) return;

        const bookId = card.getAttribute('data-book') || '';
        const userId = fUserId.value || '';

        if (!bookId || !userId) return;

        fBookId.value = bookId;
        issueForm.submit();
    });
    const extendModal = $('#extendModal');
    const extSub = document.getElementById('extSub');
    const extBookTitle = document.getElementById('extBookTitle');
    const extBookAuthor = document.getElementById('extBookAuthor');
    const extUserId = document.getElementById('extUserId');
    const extBookId = document.getElementById('extBookId');
    const extDays = document.getElementById('extDays');

    document.querySelectorAll('.js-open-extend').forEach(btn => {
        btn.addEventListener('click', function(){
            const userId = this.getAttribute('data-user');
            const bookId = this.getAttribute('data-book');
            const title = this.getAttribute('data-title') || 'Книга';
            const author = this.getAttribute('data-author') || '';

            const uname = nameMap[String(userId)] || 'Пользователь';

            extSub.textContent = 'Продление срока возврата для ' + uname;
            extBookTitle.textContent = title;
            extBookAuthor.textContent = author;

            extUserId.value = userId || '';
            extBookId.value = bookId || '';
            extDays.value = String(defaultExtDays);

            extendModal.modal('show');
        });
    });
})();
</script>

</body>
</html>