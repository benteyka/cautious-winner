<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../includes/config.php');
include('../includes/db.php');

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$activeTab = 'search';

$didSearch = (isset($_GET['do']) && (string)$_GET['do'] === '1');

$titleQ  = isset($_GET['title']) ? trim((string)$_GET['title']) : '';
$authorQ = isset($_GET['author']) ? trim((string)$_GET['author']) : '';
$isbnQ   = isset($_GET['isbn']) ? trim((string)$_GET['isbn']) : '';
$genreQ  = isset($_GET['genre']) ? trim((string)$_GET['genre']) : '';

$legacySearch = isset($_GET['search']) ? trim((string)$_GET['search']) : '';
if ($didSearch && $titleQ === '' && $authorQ === '' && $isbnQ === '' && $genreQ === '' && $legacySearch !== '') {
    $titleQ = $legacySearch;
}

$error = '';
$booksData = [];
$hasIsbn = false;

if ($didSearch) {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $error = 'Ошибка подключения к базе данных.';
    } else {
        $resCols = $conn->query("SHOW COLUMNS FROM `books` LIKE 'isbn'");
        if ($resCols && $resCols->num_rows > 0) $hasIsbn = true;

        $fields = "id, title, author, genre, status" . ($hasIsbn ? ", isbn" : "");
        $hasAnyFilter = ($titleQ !== '' || $authorQ !== '' || $isbnQ !== '' || $genreQ !== '');

        if (!$hasAnyFilter) {
            $sql = "SELECT $fields FROM books ORDER BY id DESC";
            $result = $conn->query($sql);
            if ($result) {
                while ($row = $result->fetch_assoc()) $booksData[] = $row;
            } else {
                $error = 'Не удалось загрузить книги.';
            }
        } else {
            $sql = "SELECT $fields FROM books WHERE 1=1";
            $types = '';
            $params = [];

            if ($titleQ !== '') { $sql .= " AND title LIKE ?";  $types .= 's'; $params[] = '%' . $titleQ . '%'; }
            if ($authorQ !== ''){ $sql .= " AND author LIKE ?"; $types .= 's'; $params[] = '%' . $authorQ . '%'; }
            if ($genreQ !== '') { $sql .= " AND genre LIKE ?";  $types .= 's'; $params[] = '%' . $genreQ . '%'; }

            if ($isbnQ !== '') {
                if ($hasIsbn) {
                    $sql .= " AND isbn LIKE ?";
                    $types .= 's';
                    $params[] = '%' . $isbnQ . '%';
                } else {
                    $digits = preg_replace('/\D+/', '', $isbnQ);
                    if ($digits !== '' && strlen($digits) <= 10) {
                        $asInt = (int)$digits;
                        if ($asInt > 0) {
                            $sql .= " AND id = ?";
                            $types .= 'i';
                            $params[] = $asInt;
                        }
                    } else {
                        $sql .= " AND (title LIKE ? OR author LIKE ? OR genre LIKE ?)";
                        $types .= 'sss';
                        $like = '%' . $isbnQ . '%';
                        $params[] = $like; $params[] = $like; $params[] = $like;
                    }
                }
            }

            $sql .= " ORDER BY id DESC";

            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                $error = 'Ошибка подготовки запроса поиска.';
            } else {
                $bind = [];
                $bind[] = $types;
                for ($i = 0; $i < count($params); $i++) $bind[] = &$params[$i];
                call_user_func_array([$stmt, 'bind_param'], $bind);

                $stmt->execute();

                if (method_exists($stmt, 'get_result')) {
                    $result = $stmt->get_result();
                    if ($result) {
                        while ($row = $result->fetch_assoc()) $booksData[] = $row;
                    }
                } else {
                    $id = $t = $a = $g = $s = $iVal = null;
                    if ($hasIsbn) {
                        $stmt->bind_result($id, $t, $a, $g, $s, $iVal);
                        while ($stmt->fetch()) $booksData[] = ['id'=>$id,'title'=>$t,'author'=>$a,'genre'=>$g,'status'=>$s,'isbn'=>$iVal];
                    } else {
                        $stmt->bind_result($id, $t, $a, $g, $s);
                        while ($stmt->fetch()) $booksData[] = ['id'=>$id,'title'=>$t,'author'=>$a,'genre'=>$g,'status'=>$s];
                    }
                }

                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск | Библиотека</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1206'); ?>" rel="stylesheet">

    <style>
        .adv-search-card{
            background:#fff;
            border:1px solid rgba(122,63,242,.22);
            border-radius:16px;
            padding:18px 18px 14px;
            box-shadow:0 8px 18px rgba(17,24,39,.06);
        }
        .adv-search-head{ display:flex; align-items:flex-start; gap:10px; }
        .adv-search-icon{
            width:28px;height:28px;border:1px solid rgba(122,63,242,.35);
            border-radius:10px;display:flex;align-items:center;justify-content:center;
            color:#7A3FF2;background:rgba(122,63,242,.08);margin-top:2px;flex:0 0 auto;
        }
        .adv-search-title{ font-weight:900; font-size:18px; color:#111827; line-height:1.2; }
        .adv-search-subtitle{ font-size:13px; color:#6b7280; margin-top:2px; }
        .adv-label{ font-size:12px; font-weight:900; color:#111827; margin-bottom:6px; }
        .adv-input{
            border:1px solid rgba(122,63,242,.18);
            border-radius:12px;height:42px;font-size:14px;padding:10px 12px;background:#fff;
        }
        .adv-input:focus{ outline:none; box-shadow:none; border-color:rgba(122,63,242,.65); }
        .adv-btn{
            width:100%; border:none; border-radius:12px; height:46px;
            background:#7A3FF2; color:#fff; font-weight:900;
            display:flex; align-items:center; justify-content:center; gap:8px; cursor:pointer;
        }

        .book-card{
            background:#fff;
            border:1px solid rgba(122,63,242,.22);
            border-radius:18px;
            box-shadow:0 8px 22px rgba(17,24,39,.06);
            padding:12px;
            height:100%;
            cursor:pointer;
            transition:transform .15s ease, box-shadow .15s ease;
        }
        .book-card:hover{ transform:translateY(-2px); box-shadow:0 14px 30px rgba(17,24,39,.08); }

        .book-top{ display:flex; align-items:flex-start; justify-content:space-between; gap:10px; margin-bottom:10px; }
        .book-cover{
            width:44px;height:44px;border-radius:12px;object-fit:cover;
            border:1px solid rgba(122,63,242,.18);background:rgba(122,63,242,.08);flex:0 0 auto;
        }
        .status-pill{
            height:24px; padding:0 10px; border-radius:999px; font-weight:900; font-size:12px;
            display:inline-flex; align-items:center; justify-content:center; white-space:nowrap;
        }
        .status-available{ background:rgba(122,63,242,.14); color:#5b21b6; border:1px solid rgba(122,63,242,.25); }
        .status-issued{ background:rgba(34,197,94,.12); color:#15803d; border:1px solid rgba(34,197,94,.22); }

        .book-title{ font-weight:900; font-size:16px; color:#1f1633; margin-bottom:4px; line-height:1.2; }
        .book-author{ font-weight:800; font-size:13px; color:rgba(31,22,51,.55); margin-bottom:10px; }
        .genre-pill{
            display:inline-flex; align-items:center; height:22px; padding:0 10px; border-radius:999px;
            background:rgba(122,63,242,.08); border:1px solid rgba(122,63,242,.18);
            color:#1f1633; font-weight:900; font-size:12px;
        }

        .modal-content{
            border-radius:18px;
            border:1px solid rgba(122,63,242,.20);
            box-shadow:0 22px 60px rgba(17,24,39,.16);
            overflow:hidden;
        }
        .book-modal-body{ padding:14px; }
        .book-modal-head{ display:flex; justify-content:space-between; gap:12px; align-items:flex-start; }
        .book-modal-left{ display:flex; gap:10px; align-items:flex-start; }
        .book-modal-cover{
            width:40px;height:40px;border-radius:12px;object-fit:cover;
            border:1px solid rgba(122,63,242,.18);background:rgba(122,63,242,.08);flex:0 0 auto;
        }
        .book-modal-title{ font-weight:900; font-size:17px; color:#1f1633; line-height:1.2; }
        .book-modal-author{ font-weight:800; font-size:12px; color:rgba(31,22,51,.55); margin-top:2px; }

        .book-modal-row{ margin-top:10px; display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
        .mstatus-pill{
            height:22px; padding:0 10px; border-radius:999px; font-weight:900; font-size:12px;
            display:inline-flex; align-items:center; justify-content:center; white-space:nowrap;
        }
        .mstatus-available{ background:#8b5cf6; color:#fff; border:1px solid rgba(122,63,242,.28); }
        .mstatus-issued{ background:rgba(220,53,69,0.10); color:#b02a37; border:1px solid rgba(220,53,69,0.22); }
        .book-modal-isbn{
            width:100%;
            margin-top:10px;
            font-weight:900;
            font-size:12px;
            color:rgba(31,22,51,.45);
        }
        .book-modal-actions{ margin-top:12px; }
        .book-modal-form{ width:100%; display:flex; align-items:center; gap:12px; }
        .book-modal-note{
            flex:0 0 48%; min-width:0; height:40px; border-radius:12px;
            border:1px solid rgba(122,63,242,.22); padding:0 12px; font-weight:900; outline:none; background:#fff;
        }
        .book-modal-btn{
            flex:1 1 auto; height:40px; border-radius:12px; border:none; background:#7a3ff2; color:#fff;
            font-weight:900; box-shadow:0 12px 26px rgba(122,63,242,.25);
            display:inline-flex; align-items:center; justify-content:center; gap:10px; cursor:pointer;
        }
        .book-modal-btn:disabled{ opacity:.6; cursor:not-allowed; box-shadow:none; }

        .toastx{
            position:fixed; right:16px; bottom:16px; z-index:9999;
            background:#111827; color:#fff; padding:10px 12px; border-radius:12px; font-weight:900;
            box-shadow:0 16px 40px rgba(0,0,0,.22); opacity:0; transform:translateY(10px);
            transition:opacity .15s ease, transform .15s ease; pointer-events:none;
        }
        .toastx.show{ opacity:1; transform:translateY(0); }

        @media (max-width: 575.98px){
            .book-modal-form{ flex-direction:column; align-items:stretch; }
            .book-modal-note{ width:100%; }
            .book-modal-btn{ width:100%; }
        }
    </style>
</head>
<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-2">
    <?php include('../includes/section_tabs.php'); ?>

    <form action="<?php echo url('/pages/search.php'); ?>" method="GET" class="mb-3">
        <input type="hidden" name="do" value="1">

        <div class="adv-search-card">
            <div class="adv-search-head mb-3">
                <div class="adv-search-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z" stroke="currentColor" stroke-width="2"/>
                        <path d="M16.2 16.2 21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <div>
                    <div class="adv-search-title">Расширенный поиск</div>
                    <div class="adv-search-subtitle">Найдите нужную книгу по различным критериям</div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-md-6 mb-3">
                    <div class="adv-label">Название книги</div>
                    <input type="text" name="title" class="form-control adv-input"
                           value="<?php echo htmlspecialchars($titleQ); ?>"
                           placeholder="Например: 1984" autocomplete="off">
                </div>

                <div class="col-12 col-md-6 mb-3">
                    <div class="adv-label">Автор</div>
                    <input type="text" name="author" class="form-control adv-input"
                           value="<?php echo htmlspecialchars($authorQ); ?>"
                           placeholder="Например: Оруэлл" autocomplete="off">
                </div>

                <div class="col-12 col-md-6 mb-3">
                    <div class="adv-label">ISBN</div>
                    <input type="text" name="isbn" class="form-control adv-input"
                           value="<?php echo htmlspecialchars($isbnQ); ?>"
                           placeholder="978-5-17-098825-6" autocomplete="off">
                </div>

                <div class="col-12 col-md-6 mb-3">
                    <div class="adv-label">Жанр</div>
                    <input type="text" name="genre" class="form-control adv-input"
                           value="<?php echo htmlspecialchars($genreQ); ?>"
                           placeholder="Например: Фэнтези" autocomplete="off">
                </div>
            </div>

            <button class="adv-btn" type="submit">
                <span class="adv-btn-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z" stroke="currentColor" stroke-width="2"/>
                        <path d="M16.2 16.2 21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </span>
                Найти книги
            </button>
        </div>
    </form>

    <?php if ($didSearch): ?>
        <div class="search-results-wrap">
            <?php if ($error !== ''): ?>
                <div class="adv-empty" style="border-color: rgba(239,68,68,0.25); color: rgba(239,68,68,0.9);">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php else: ?>
                <?php if (count($booksData) === 0): ?>
                    <div class="adv-empty">Книги не найдены.</div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($booksData as $row):
                            $bookId = (int)$row['id'];
                            $title = (string)$row['title'];
                            $author = (string)$row['author'];
                            $genre = (string)$row['genre'];
                            $status = (string)$row['status'];
                            $isbn = ($hasIsbn && isset($row['isbn'])) ? (string)$row['isbn'] : '';
                        ?>
                            <div class="col-md-3 col-sm-6 mb-3">
                                <div class="book-card js-book"
                                     data-id="<?php echo $bookId; ?>"
                                     data-title="<?php echo htmlspecialchars($title, ENT_QUOTES); ?>"
                                     data-author="<?php echo htmlspecialchars($author, ENT_QUOTES); ?>"
                                     data-genre="<?php echo htmlspecialchars($genre, ENT_QUOTES); ?>"
                                     data-status="<?php echo htmlspecialchars($status, ENT_QUOTES); ?>"
                                     data-isbn="<?php echo htmlspecialchars($isbn, ENT_QUOTES); ?>"
                                     tabindex="0" role="button" aria-label="Открыть книгу">
                                    <div class="book-top">
                                        <img src="<?php echo url('/assets/images/f.jpg'); ?>" class="book-cover" alt="cover">

                                        <?php if ($status === 'issued') { ?>
                                            <span class="status-pill status-issued">Выдана</span>
                                        <?php } else { ?>
                                            <span class="status-pill status-available">Доступна</span>
                                        <?php } ?>
                                    </div>

                                    <div class="book-title"><?php echo htmlspecialchars($title); ?></div>
                                    <div class="book-author"><?php echo htmlspecialchars($author); ?></div>

                                    <div>
                                        <span class="genre-pill"><?php echo htmlspecialchars($genre); ?></span>
                                    </div>

                                    
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>


<div class="modal fade" id="bookModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:520px;">
    <div class="modal-content">
      <div class="book-modal-body">
        <div class="book-modal-head">
          <div class="book-modal-left">
            <img src="<?php echo url('/assets/images/f.jpg'); ?>" class="book-modal-cover" alt="cover">
            <div>
              <div class="book-modal-title" id="mTitle">Книга</div>
              <div class="book-modal-author" id="mAuthor">Автор</div>
            </div>
          </div>

          <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="opacity:.55;">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="book-modal-row">
          <span class="mstatus-pill mstatus-available" id="mStatus">Доступна</span>
          <span class="genre-pill" id="mGenre">Жанр</span>
        </div>

        <div class="book-modal-isbn" id="mIsbn" style="display:none;">ISBN: </div>

        <div class="book-modal-actions">
          <form method="POST" action="<?php echo url('/pages/borrow.php'); ?>" id="borrowForm" class="book-modal-form" style="margin:0;">
            <input type="hidden" name="book_id" id="mBookId" value="">
            <input type="text" name="note" id="mNote" class="book-modal-note" placeholder="" autocomplete="off">
            <button type="submit" class="book-modal-btn" id="mBorrowBtn">
              <span aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                  <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                </svg>
              </span>
              Взять книгу
            </button>
          </form>
        </div>

        <div id="mHint" style="margin-top:8px; font-weight:900; font-size:12px; color:rgba(31,22,51,.45); display:none;">
          Гость не может взять книгу. Войдите в аккаунт.
        </div>
      </div>
    </div>
  </div>
</div>

<div class="toastx" id="toastx">Гость не может взять книгу</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
(function(){
  const isAuthorized = <?php echo $isAuthorized ? 'true' : 'false'; ?>;

  const modalEl = $('#bookModal');
  const mTitle = document.getElementById('mTitle');
  const mAuthor = document.getElementById('mAuthor');
  const mGenre = document.getElementById('mGenre');
  const mStatus = document.getElementById('mStatus');
  const mIsbn = document.getElementById('mIsbn');
  const mBookId = document.getElementById('mBookId');
  const mNote = document.getElementById('mNote');
  const mBorrowBtn = document.getElementById('mBorrowBtn');
  const mHint = document.getElementById('mHint');

  const toast = document.getElementById('toastx');
  let toastTimer = null;

  function showToast(text){
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1600);
  }

  function openBook(card){
    const id = card.dataset.id || '';
    const title = card.dataset.title || '';
    const author = card.dataset.author || '';
    const genre = card.dataset.genre || '';
    const status = card.dataset.status || '';
    const isbn = card.dataset.isbn || '';

    mBookId.value = id;
    if (mNote) { mNote.value = ''; }
    mTitle.textContent = title;
    mAuthor.textContent = author;
    mGenre.textContent = genre;

    if (isbn && isbn.trim() !== '') {
      mIsbn.style.display = 'block';
      mIsbn.textContent = 'ISBN: ' + isbn;
    } else {
      mIsbn.style.display = 'none';
      mIsbn.textContent = '';
    }

    if (status === 'issued') {
      mStatus.textContent = 'Выдана';
      mStatus.classList.remove('mstatus-available');
      mStatus.classList.add('mstatus-issued');
      mBorrowBtn.disabled = true;
      if (mNote) { mNote.disabled = true; }
      mHint.style.display = 'none';
    } else {
      mStatus.textContent = 'Доступна';
      mStatus.classList.remove('mstatus-issued');
      mStatus.classList.add('mstatus-available');
      mBorrowBtn.disabled = false;
      if (mNote) { mNote.disabled = false; }
      mHint.style.display = (!isAuthorized) ? 'block' : 'none';
    }

    modalEl.modal('show');
  }

  function bindCards(){
    document.querySelectorAll('.js-book').forEach(card => {
      if (card.dataset.bound === '1') return;
      card.dataset.bound = '1';

      card.addEventListener('click', () => openBook(card));
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openBook(card);
        }
      });
    });
  }

  bindCards();

  document.getElementById('borrowForm').addEventListener('submit', function(e){
    if (!isAuthorized) {
      e.preventDefault();
      showToast('Гость не может взять книгу');
    }
  });
})();
</script>

</body>
</html>