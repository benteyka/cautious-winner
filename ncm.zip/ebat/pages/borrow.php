<?php
include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$userId = 0;
if (!empty($_SESSION['user_id'])) $userId = (int)$_SESSION['user_id'];
else if (!empty($_SESSION['id'])) $userId = (int)$_SESSION['id'];
else if (!empty($_SESSION['user']['id'])) $userId = (int)$_SESSION['user']['id'];

if (!$isAuthorized || $userId <= 0) {
    header("Location: " . url('/pages/login.php') . "?redirect=" . urlencode(url('/pages/index.php')));
    exit;
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    header("Location: " . url('/pages/index.php'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . url('/pages/index.php'));
    exit;
}

$bookId = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;
if ($bookId <= 0) {
    header("Location: " . url('/pages/index.php'));
    exit;
}

function table_exists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function index_exists(mysqli $conn, string $table, string $indexName): bool {
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND INDEX_NAME = ?
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param('ss', $table, $indexName);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
    return ($res && $res->num_rows > 0);
}

function ensure_book_requests_schema(mysqli $conn): void {
    $conn->query(
        "CREATE TABLE IF NOT EXISTS `book_requests` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `book_id` int(11) NOT NULL,
            `date_requested` datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    );

    
    if (!index_exists($conn, 'book_requests', 'idx_br_user')) {
        $conn->query("ALTER TABLE `book_requests` ADD KEY `idx_br_user` (`user_id`)");
    }
    if (!index_exists($conn, 'book_requests', 'idx_br_book')) {
        $conn->query("ALTER TABLE `book_requests` ADD KEY `idx_br_book` (`book_id`)");
    }
    if (!index_exists($conn, 'book_requests', 'idx_br_user_book')) {
        $conn->query("ALTER TABLE `book_requests` ADD KEY `idx_br_user_book` (`user_id`,`book_id`)");
    }
}

try {
    ensure_book_requests_schema($conn);

    
    $stmt = $conn->prepare("SELECT title, status FROM books WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $bookId);
    $stmt->execute();
    $res = $stmt->get_result();
    $bk = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    if (!$bk) {
        header("Location: " . url('/pages/index.php'));
        exit;
    }

    if ((string)$bk['status'] !== 'available') {
        
        $back = !empty($_SERVER['HTTP_REFERER']) ? (string)$_SERVER['HTTP_REFERER'] : url('/pages/index.php');
        if (strpos($back, BASE_URL) === false) $back = url('/pages/index.php');
        $sep = (strpos($back, '?') === false) ? '?' : '&';
        header("Location: " . $back . $sep . "req=0");
        exit;
    }

    
    $stmt = $conn->prepare("SELECT id FROM book_requests WHERE user_id=? AND book_id=? ORDER BY date_requested DESC, id DESC LIMIT 1");
    $stmt->bind_param("ii", $userId, $bookId);
    $stmt->execute();
    $res = $stmt->get_result();
    $rq = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    if ($rq && !empty($rq['id'])) {
        $rid = (int)$rq['id'];
        $stmt = $conn->prepare("UPDATE book_requests SET date_requested=NOW() WHERE id=?");
        $stmt->bind_param("i", $rid);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("INSERT INTO book_requests (user_id, book_id, date_requested) VALUES (?, ?, NOW())");
        $stmt->bind_param("ii", $userId, $bookId);
        $stmt->execute();
        $stmt->close();
    }

    
    if (table_exists($conn, 'notifications')) {
        $msg = 'Заявка на книгу "' . (string)$bk['title'] . '" отправлена. Ожидайте выдачи от администратора.';
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, date_created) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $userId, $msg);
        $stmt->execute();
        $stmt->close();
    }

    $back = !empty($_SERVER['HTTP_REFERER']) ? (string)$_SERVER['HTTP_REFERER'] : url('/pages/index.php');
    if (strpos($back, BASE_URL) === false) $back = url('/pages/index.php');
    $sep = (strpos($back, '?') === false) ? '?' : '&';
    header("Location: " . $back . $sep . "req=1");
    exit;

} catch (Throwable $e) {
    header("Location: " . url('/pages/index.php') . "?req=0");
    exit;
}