<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userRole = '';
if (!empty($_SESSION['user']['role'])) $userRole = (string)$_SESSION['user']['role'];

$isAdmin = (strtolower($userRole) === 'admin');
$activeTab = isset($activeTab) ? $activeTab : 'catalog';

function tab_class($name, $activeTab) {
    return ($name === $activeTab) ? 'tabs-link tabs-active' : 'tabs-link';
}
?>
<style>
/* Миниатюрные вкладки: слева над поиском, аккуратно */
.tabs-wrap{
    width: 100%;
    margin: 10px 0 10px 0;
    display:flex;
    justify-content:flex-start;
}
.tabs-shell{
    display:flex;
    align-items:center;
    gap:6px;
    padding:5px;
    border-radius:14px;
    background:#fff;
    border:1px solid rgba(122,63,242,.22);
    box-shadow:0 8px 18px rgba(17,24,39,.06);
    flex-wrap: wrap;
}
.tabs-link{
    display:inline-flex;
    align-items:center;
    gap:8px;
    height:32px;                  /* меньше */
    padding:0 12px;               /* меньше */
    border-radius:12px;
    color:rgba(31,22,51,.70);
    font-weight:900;
    font-size:13px;               /* меньше */
    text-decoration:none !important;
    border:1px solid transparent;
    background:transparent;
    transition:all .12s ease;
    white-space:nowrap;
}
.tabs-link:hover{
    background:rgba(122,63,242,.08);
    color:rgba(31,22,51,.88);
}
.tabs-active{
    background:rgba(122,63,242,.14);
    border-color:rgba(122,63,242,.26);
    color:#1f1633;
}
.tab-ico{
    width:16px;height:16px;       /* меньше */
    display:inline-flex;
    align-items:center;
    justify-content:center;
    color:rgba(122,63,242,.95);
}
</style>

<div class="tabs-wrap">
    <div class="tabs-shell">
        <a class="<?php echo tab_class('catalog',$activeTab); ?>" href="<?php echo url('/pages/index.php'); ?>">
            <span class="tab-ico" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M4 19a2 2 0 0 0 2 2h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M6 17V5a2 2 0 0 1 2-2h12v16H8a2 2 0 0 0-2 2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                </svg>
            </span>
            Каталог
        </a>

        <a class="<?php echo tab_class('search',$activeTab); ?>" href="<?php echo url('/pages/search.php'); ?>">
            <span class="tab-ico" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z" stroke="currentColor" stroke-width="2"/>
                    <path d="M16.2 16.2 21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </span>
            Поиск
        </a>

        <a class="<?php echo tab_class('my_books',$activeTab); ?>" href="<?php echo url('/pages/my_books.php'); ?>">
            <span class="tab-ico" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M7 3h10a2 2 0 0 1 2 2v16l-7-4-7 4V5a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                </svg>
            </span>
            Мои книги
        </a>

        <?php if ($isAdmin) { ?>
            <a class="<?php echo tab_class('manage',$activeTab); ?>" href="<?php echo url('/pages/manage.php'); ?>">
                <span class="tab-ico" aria-hidden="true">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" stroke="currentColor" stroke-width="2"/>
                        <path d="M19.4 15a7.9 7.9 0 0 0 .1-2l2-1.1-2-3.4-2.3.6a8.1 8.1 0 0 0-1.7-1l-.3-2.4H9.8l-.3 2.4a8.1 8.1 0 0 0-1.7 1l-2.3-.6-2 3.4 2 1.1a7.9 7.9 0 0 0 .1 2l-2 1.1 2 3.4 2.3-.6a8.1 8.1 0 0 0 1.7 1l.3 2.4h4.4l.3-2.4a8.1 8.1 0 0 0 1.7-1l2.3.6 2-3.4-2-1.1Z"
                              stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
                    </svg>
                </span>
                Управление
            </a>
        <?php } ?>
    </div>
</div>
