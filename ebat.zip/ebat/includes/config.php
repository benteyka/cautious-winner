<?php
declare(strict_types=1);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

/**
 * Проект лежит: C:\xampp1\htdocs\ebat
 * Значит в браузере: http://localhost/ebat
 */
define('BASE_URL', '/ebat');

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'f1226446_library_system'); // имя базы в phpMyAdmin на локалке
define('DB_USER', 'root');
define('DB_PASS', '');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$conn->set_charset('utf8mb4');

function url(string $path): string {
    $base = rtrim(BASE_URL, '/');
    $p = '/' . ltrim($path, '/');
    return $base . $p;
}
