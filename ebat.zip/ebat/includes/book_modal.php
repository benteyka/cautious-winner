<?php
// Модалка книги + уведомление (тост)
?>
<div class="modal fade" id="bookModal" tabindex="-1" role="dialog" aria-labelledby="bookModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content book-modal-content">

      <div class="book-modal-header">
        <div class="book-modal-left">
          <img id="bmCover" class="book-modal-cover" src="<?php echo url('/assets/images/f.jpg'); ?>" alt="cover">
          <div class="book-modal-meta">
            <div id="bmTitle" class="book-modal-title">—</div>
            <div id="bmAuthor" class="book-modal-author">—</div>

            <div class="book-modal-pills">
              <span id="bmStatus" class="bm-pill bm-status">—</span>
              <span id="bmGenre" class="bm-pill bm-genre">—</span>
            </div>

            <!-- ISBN ДОЛЖЕН БЫТЬ ПОД "ДОСТУПНА/ВЫДАНА" -->
            <div class="book-modal-isbn">
              <span class="bm-isbn-label">ISBN:</span>
              <span id="bmIsbn" class="bm-isbn-value">—</span>
            </div>
          </div>
        </div>

        <button type="button" class="book-modal-close" data-dismiss="modal" aria-label="Close">×</button>
      </div>

      <div class="book-modal-body">
        <div class="book-modal-actions">
          <!-- поле ввода ЕСТЬ, но без моих слов -->
          <input id="bmNote" type="text" class="book-modal-input" placeholder="">
          <button id="bmTakeBtn" type="button" class="book-modal-take">
            <span class="bm-btn-ico" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M7 7h10v10H7V7Z" stroke="currentColor" stroke-width="2"/>
                <path d="M9 12h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </span>
            Взять книгу
          </button>
        </div>
      </div>

    </div>
  </div>
</div>

<div id="toastBox" class="toast-box" aria-live="polite" aria-atomic="true" style="display:none;">
  <div id="toastMsg" class="toast-msg">—</div>
</div>
