(function () {
  function qs(sel) { return document.querySelector(sel); }

  function showToast(text) {
    var box = qs('#toastBox');
    var msg = qs('#toastMsg');
    if (!box || !msg) return;

    msg.textContent = text;
    box.style.display = 'block';
    box.classList.remove('toast-show');
    void box.offsetWidth;
    box.classList.add('toast-show');

    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(function () {
      box.classList.remove('toast-show');
      setTimeout(function () { box.style.display = 'none'; }, 220);
    }, 1800);
  }

  function setStatusPill(el, status) {
    if (!el) return;
    el.classList.remove('bm-status-available', 'bm-status-issued');

    if (status === 'available') {
      el.textContent = 'Доступна';
      el.classList.add('bm-status-available');
    } else if (status === 'issued') {
      el.textContent = 'Выдана';
      el.classList.add('bm-status-issued');
    } else {
      el.textContent = status || '—';
    }
  }

  function openModalFromCard(card) {
    var title = card.getAttribute('data-title') || '—';
    var author = card.getAttribute('data-author') || '—';
    var genre = card.getAttribute('data-genre') || '—';
    var status = card.getAttribute('data-status') || '—';
    var isbn = card.getAttribute('data-isbn') || '';
    var id = card.getAttribute('data-id') || '';

    var bmTitle = qs('#bmTitle');
    var bmAuthor = qs('#bmAuthor');
    var bmGenre = qs('#bmGenre');
    var bmStatus = qs('#bmStatus');
    var bmIsbn = qs('#bmIsbn');
    var bmTakeBtn = qs('#bmTakeBtn');
    var bmNote = qs('#bmNote');

    if (bmTitle) bmTitle.textContent = title;
    if (bmAuthor) bmAuthor.textContent = author;
    if (bmGenre) bmGenre.textContent = genre;

    setStatusPill(bmStatus, status);

    // ISBN показываем ВСЕГДА (если пусто — ставим "—")
    if (bmIsbn) bmIsbn.textContent = (isbn && isbn.trim() !== '') ? isbn : '—';

    // очищаем поле ввода при открытии
    if (bmNote) bmNote.value = '';

    if (bmTakeBtn) {
      bmTakeBtn.setAttribute('data-book-id', id);
      bmTakeBtn.setAttribute('data-status', status);

      // если книга выдана — кнопка disabled
      bmTakeBtn.disabled = (status !== 'available');
    }

    if (window.jQuery && jQuery('#bookModal').length) {
      jQuery('#bookModal').modal('show');
    }
  }

  function init() {
    // клик по карточке
    document.addEventListener('click', function (e) {
      var card = e.target.closest('.book-card[data-clickable="1"]');
      if (!card) return;
      openModalFromCard(card);
    });

    // клик по "Взять книгу"
    var btn = qs('#bmTakeBtn');
    if (btn) {
      btn.addEventListener('click', function () {
        var isAuth = (document.body.getAttribute('data-auth') === '1');
        var status = btn.getAttribute('data-status');

        if (status !== 'available') {
          showToast('Эта книга недоступна.');
          return;
        }

        if (!isAuth) {
          showToast('Гость не может взять книгу. Войдите в аккаунт.');
          return;
        }

        // backend не трогаем, просто уведомление без лишних слов
        showToast('Заявка отправлена.');
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
