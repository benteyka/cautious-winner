<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function login_safe_redirect(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return url('/pages/index.php');

    $base = rtrim(BASE_URL, '/');
    if (strpos($raw, $base . '/pages/') === 0) return $raw;

    // совместимость со старым форматом: /pages/...
    if (strpos($raw, '/pages/') === 0) return url($raw);

    return url('/pages/index.php');
}

function login_table_exists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    return ($res && $res->num_rows > 0);
}

function login_get_columns(mysqli $conn, string $table): array {
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            if (!empty($row['Field'])) $cols[] = $row['Field'];
        }
    }
    return $cols;
}

function login_pick_col(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) {
        if (in_array($c, $cols, true)) return $c;
    }
    return null;
}

function login_is_hash(string $s): bool {
    $s = trim($s);
    return (strpos($s, '$2y$') === 0) || (strpos($s, '$2a$') === 0) || (strpos($s, '$argon2') === 0);
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$redirect = isset($_GET['redirect']) ? login_safe_redirect($_GET['redirect']) : url('/pages/index.php');

if ($isAuthorized) {
    header("Location: " . $redirect);
    exit;
}

$error = '';
$identifier = '';

if (!isset($conn) || !($conn instanceof mysqli)) {
    $error = 'Нет соединения с базой данных.';
} else if (!login_table_exists($conn, 'users')) {
    $error = 'Таблица users не найдена.';
}

if ($error === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = isset($_POST['identifier']) ? trim($_POST['identifier']) : '';
    $password   = isset($_POST['password']) ? (string)$_POST['password'] : '';

    if ($identifier === '' || $password === '') {
        $error = 'Заполни логин и пароль.';
    } else {
        $cols = login_get_columns($conn, 'users');

        $idCol       = login_pick_col($cols, ['id', 'user_id']);
        $usernameCol = login_pick_col($cols, ['username', 'login', 'name']);
        $emailCol    = login_pick_col($cols, ['email']);
        $passCol     = login_pick_col($cols, ['password_hash', 'password', 'pass']);
        $roleCol     = login_pick_col($cols, ['role', 'user_role', 'type']);

        if (!$idCol || !$passCol || (!$usernameCol && !$emailCol)) {
            $error = 'В users не хватает колонок для входа.';
        } else {
            // Разрешаем вход по email ИЛИ username
            if ($emailCol && $usernameCol) {
                $sql = "SELECT * FROM `users` WHERE `$emailCol` = ? OR `$usernameCol` = ? LIMIT 1";
                $stmt = $conn->prepare($sql);
                if ($stmt) $stmt->bind_param("ss", $identifier, $identifier);
            } else {
                $loginCol = $emailCol ? $emailCol : $usernameCol;
                $sql = "SELECT * FROM `users` WHERE `$loginCol` = ? LIMIT 1";
                $stmt = $conn->prepare($sql);
                if ($stmt) $stmt->bind_param("s", $identifier);
            }

            if (!$stmt) {
                $error = 'Ошибка запроса к users.';
            } else {
                $stmt->execute();
                $res = $stmt->get_result();
                $user = $res ? $res->fetch_assoc() : null;

                if (!$user) {
                    $error = 'Неверный логин или пароль.';
                } else {
                    $stored = (string)$user[$passCol];
                    $ok = false;

                    if ($stored !== '') {
                        if (login_is_hash($stored)) {
                            $ok = password_verify($password, $stored);
                        } else {
                            // У тебя сейчас plaintext (password123 / adminpassword)
                            $ok = hash_equals($stored, $password);
                        }
                    }

                    if (!$ok) {
                        $error = 'Неверный логин или пароль.';
                    } else {
                        session_regenerate_id(true);

                        $uid = (int)$user[$idCol];
                        $role = ($roleCol && isset($user[$roleCol]) && $user[$roleCol] !== '') ? (string)$user[$roleCol] : 'reader';

                        $_SESSION['user_id'] = $uid;
                        $_SESSION['logged_in'] = true;
                        $_SESSION['is_auth'] = true;
                        $_SESSION['user'] = [
                            'id' => $uid,
                            'login' => $identifier,
                            'role' => $role
                        ];

                        header("Location: " . $redirect);
                        exit;
                    }
                }

                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1202'); ?>" rel="stylesheet">
</head>
<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-4">

    <div class="adv-search-card" style="max-width: 560px; margin: 0 auto;">
        <div class="adv-search-head">
            <div class="adv-search-icon" aria-hidden="true">🔐</div>
            <div>
                <div class="adv-search-title">Вход</div>
                <div class="adv-search-subtitle">Введи email/логин и пароль</div>
            </div>
        </div>

        <?php if ($error !== '') { ?>
            <div class="mt-3 adv-empty" style="border-color: rgba(239,68,68,0.25); color: rgba(239,68,68,0.9);">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php } ?>

        <?php if (isset($_GET['registered']) && $_GET['registered'] === '1') { ?>
            <div class="mt-3 adv-empty" style="border-color: rgba(34,197,94,0.25); color: rgba(21,128,61,0.95);">
                Регистрация успешно завершена. Теперь войди в аккаунт.
            </div>
        <?php } ?>

        <form method="POST" action="<?php echo url('/pages/login.php'); ?>?redirect=<?php echo urlencode($redirect); ?>" class="mt-3">
            <div class="row">
                <div class="col-12 mb-3">
                    <label class="adv-label">Email или логин</label>
                    <input class="form-control adv-input" type="text" name="identifier"
                           value="<?php echo htmlspecialchars($identifier); ?>"
                           placeholder="reader1@example.com или reader1">
                </div>

                <div class="col-12 mb-3">
                    <label class="adv-label">Пароль</label>
                    <input class="form-control adv-input" type="password" name="password"
                           placeholder="password123">
                </div>
            </div>

            <button type="submit" class="adv-btn">
                <span class="adv-btn-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M10 7H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M14 16l4-4-4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M18 12H10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </span>
                Войти
            </button>

            <div style="margin-top: 12px; text-align: center;">
                <a href="<?php echo url('/pages/register.php'); ?>"
                   style="font-weight: 800; color: #7a3ff2; text-decoration: none; border-bottom: 1px dashed rgba(122,63,242,0.35);">
                    Регистрация
                </a>
            </div>
        </form>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>