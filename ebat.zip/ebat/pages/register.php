<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

include('../includes/config.php');
include('../includes/db.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function register_safe_redirect(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') return url('/pages/index.php');

    $base = rtrim(BASE_URL, '/');
    if (strpos($raw, $base . '/pages/') === 0) return $raw;
    if (strpos($raw, '/pages/') === 0) return url($raw);

    return url('/pages/index.php');
}

$isAuthorized =
    (!empty($_SESSION['user_id'])) ||
    (!empty($_SESSION['id'])) ||
    (!empty($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) ||
    (!empty($_SESSION['is_auth']) && $_SESSION['is_auth'] === true) ||
    (!empty($_SESSION['user']) && is_array($_SESSION['user']));

$redirect = isset($_GET['redirect']) ? register_safe_redirect($_GET['redirect']) : url('/pages/index.php');

if ($isAuthorized) {
    header("Location: " . $redirect);
    exit;
}

$error = '';
$username = '';
$email = '';

if (!isset($conn) || !($conn instanceof mysqli)) {
    $error = 'Нет соединения с базой данных.';
}

if ($error === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim((string)$_POST['username']) : '';
    $email = isset($_POST['email']) ? trim((string)$_POST['email']) : '';
    $password = isset($_POST['password']) ? (string)$_POST['password'] : '';
    $password2 = isset($_POST['password_confirm']) ? (string)$_POST['password_confirm'] : '';

    if ($username === '' || $email === '' || $password === '' || $password2 === '') {
        $error = 'Заполни все поля.';
    } elseif (strlen($username) < 3) {
        $error = 'Логин должен быть не короче 3 символов.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email.';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен быть не короче 6 символов.';
    } elseif (!hash_equals($password, $password2)) {
        $error = 'Пароли не совпадают.';
    } else {
        $stmtCheck = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        if (!$stmtCheck) {
            $error = 'Ошибка проверки пользователя.';
        } else {
            $stmtCheck->bind_param('ss', $username, $email);
            $stmtCheck->execute();
            $exists = $stmtCheck->get_result();
            if ($exists && $exists->num_rows > 0) {
                $error = 'Пользователь с таким логином или email уже существует.';
            }
            $stmtCheck->close();
        }

        if ($error === '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'reader';

            $stmtInsert = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            if (!$stmtInsert) {
                $error = 'Ошибка создания пользователя.';
            } else {
                $stmtInsert->bind_param('ssss', $username, $email, $hash, $role);
                if ($stmtInsert->execute()) {
                    $stmtInsert->close();
                    header('Location: ' . url('/pages/login.php') . '?registered=1&redirect=' . urlencode($redirect));
                    exit;
                }
                $error = 'Не удалось зарегистрировать пользователя.';
                $stmtInsert->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo url('/assets/css/styles.css?v=1202'); ?>" rel="stylesheet">
</head>
<body class="d-flex flex-column">

<?php include('../includes/header.php'); ?>

<div class="container mt-4">

    <div class="adv-search-card" style="max-width: 560px; margin: 0 auto;">
        <div class="adv-search-head">
            <div class="adv-search-icon" aria-hidden="true">📝</div>
            <div>
                <div class="adv-search-title">Регистрация</div>
                <div class="adv-search-subtitle">Создание аккаунта читателя</div>
            </div>
        </div>

        <?php if ($error !== '') { ?>
            <div class="mt-3 adv-empty" style="border-color: rgba(239,68,68,0.25); color: rgba(239,68,68,0.9);">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php } ?>

        <form method="POST" action="<?php echo url('/pages/register.php'); ?>?redirect=<?php echo urlencode($redirect); ?>" class="mt-3">
            <div class="row">
                <div class="col-12 mb-3">
                    <label class="adv-label">Логин (username)</label>
                    <input class="form-control adv-input" type="text" name="username"
                           value="<?php echo htmlspecialchars($username); ?>"
                           placeholder="reader2">
                </div>

                <div class="col-12 mb-3">
                    <label class="adv-label">Email</label>
                    <input class="form-control adv-input" type="email" name="email"
                           value="<?php echo htmlspecialchars($email); ?>"
                           placeholder="reader2@example.com">
                </div>

                <div class="col-12 mb-3">
                    <label class="adv-label">Пароль</label>
                    <input class="form-control adv-input" type="password" name="password"
                           placeholder="Минимум 6 символов">
                </div>

                <div class="col-12 mb-3">
                    <label class="adv-label">Повтори пароль</label>
                    <input class="form-control adv-input" type="password" name="password_confirm"
                           placeholder="Повтори пароль">
                </div>
            </div>

            <button type="submit" class="adv-btn">
                <span class="adv-btn-ico" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                        <path d="M12 5v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </span>
                Зарегистрироваться
            </button>

            <div style="margin-top: 12px; text-align: center;">
                <a href="<?php echo url('/pages/login.php'); ?>?redirect=<?php echo urlencode($redirect); ?>"
                   style="font-weight: 800; color: #7a3ff2; text-decoration: none; border-bottom: 1px dashed rgba(122,63,242,0.35);">
                    Уже есть аккаунт? Войти
                </a>
            </div>
        </form>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>